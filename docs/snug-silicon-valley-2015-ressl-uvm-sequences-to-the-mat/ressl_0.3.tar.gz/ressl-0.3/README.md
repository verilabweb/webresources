# RESSL #

Read-Evaluate-StartSequence-Loop

### What is this repository for? ###

RESSL is an acronym that stands for (Read Evaluate Start Sequence Loop) and is a
system inspired by the Lisp REPL (Read Evaluate Print Loop) providing an
iterative environment in SystemVerilog to launch UVM-based sequences. 

It includes a command line interpreter (Read-Evalue) and an API to create an
start UVM sequences.

More details are provided in the paper "RESSL UVM Sequences to the Mat"
presented at the SNUG Conference in March 2015 in San Jose.

* Version 0.3 

### How do I get set up? ###

Download the ressl-v0.3.tar.gz tarball.  

   * ressl.tar   = source files for the RESSL system

You will also need to download the following two tar.gz files from Verilab:

   * svlib.tar   = contains the dependent SVLib (SystemVerilog Utilities) library
   * uvm-1.2-ressl.tar = the UVM 1.2 library updated with modifications for object
     introspection used by RESSL. 

Before uncompressing and extracting the ressl-v0.3.tar.gz, use the md5sum
program to ensure that the MD5 hash (provided in the ressl-v0.3.md5) matches.
Compare the contents of the ressl-v0.3.md5 with the return values from the
command:

   # md5sum ressl-v0.3.tar.gz

Once you have verified that the tarball is complete and uncorrupted, extract the
contents and then un-tar the ressl.tar into a directory of your choice.  Download and install the svlib and modified UVM-1.2
source also.

Inside this tarball is a User Guide which includes an Installation Guide.  Further
instructions on installing and running the UVM ubus example can be found in this
Installation Guide.

The pdf version of RESSL User Guide can be found in the doc/RESSLUserGuide.pdf
sub-directory where you extracted the ressl.tar file.  Alternatively, an HTML
version of the User Guide can be found in the doc/build/html/index.html
directory.

### Who do I talk to? ###

* Bryan Morris (bryan.morris@verilab.com) or Jeff McNeal (jeff.mcneal@verilab.com)
