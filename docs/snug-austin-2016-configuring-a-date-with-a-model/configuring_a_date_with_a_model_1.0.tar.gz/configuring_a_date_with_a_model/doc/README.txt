/*-----------------------------------------------------------
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.
-----------------------------------------------------------*/

----------------------------------------------------------------------
 Verilab Inc. 2016
 Author: jeff.montesano@verilab.com
 File: README.txt
 Desc: User guide for verification environment accompanying paper 
       "How to Configure a Date with a Model"
----------------------------------------------------------------------

-------------------------
Directory Structure
-------------------------
doc:
  Contains user guide

env: 
  Contains UVM verification environment for a simple counter design

rtl:
  Contains two low-level RTL modules (a counter and the registers associated with it), and 
  a higher-level module that connects the two.

scripts:
  Contains the makefiles to compile the RTL, testbench, and run simulations

seq:
  Contains UVM sequences that are used to configure and reset the DUT

tb:
  Contains the testbench module that instantiates the DUT, as well as the register model

tests:
  Contains a simple test that stimulates the counter by programming values into
  the DUT's registers

-------------------------
Running a test
-------------------------
> cd scripts
> make -f Makefile_vcs clean runsim TESTNAME=simple_test VERBOSITY=UVM_HIGH


-------------------------
Test description
-------------------------
Test simple_test randomizes the configuration object and programs the DUT (a counter)
with the random configuration.  It then waits for the configuration to take effect, and
some time later resets the DUT.  This all happens within a "repeat" loop, so that the DUT
experiences many different random configurations.  This code goes with section 4 of the 
paper, which discusses how to keep configuration objects in sync with the DUT when there
are dynamic register fields that experience clock-domain crossings from the register clock
domain to the system clock domain.

In the waves there should be lots of activity on the counter, reset, and register signals.
Note that there are no checks in this environment other than the checker inside the 
configuration object (class block_config) that checks that the DUT and testbench configurations
are in sync.  If there is any divergence between the two, a UVM_ERROR message is printed
to the logfile (vcs.log).

In the logfile, look for the following messages:

At the time a register callback executes the post_predict function, assigning to the configuration
object's pending field, because a write transaction was noticed by the register monitor:

  UVM_INFO ../env/reg_cb.sv(137) @ 84375: reporter [REG-CBS] counter_en_cb called with value 'h1

At the time the RTL signal corresponding to a configuration register in the system clock domain changed, 
the configuration object's pending field is assigned to the configuration object's actual field:

  UVM_INFO ../env/block_config.sv(108) @ 90945: reporter [CFG] Assigning counter_en_pending to counter_en with value 'h1

Right after the assignment from pending to actual in the configuration object, a check is done of the configuration
object's actual value against the RTL signal's value:

  UVM_INFO ../env/block_config.sv(108) @ 90945: reporter [CFG] Field counter_en is in sync, value = 'h1

At the end of the simulation, there should be no errors reported:

  ** Report counts by severity
  UVM_WARNING :    0
  UVM_ERROR :    0
  UVM_FATAL :    0
  ** Report counts by id

-------------------------
Contacting the Authors
-------------------------
For any questions regarding these code examples, you can reach the authors at:
jeff.montesano@verilab.com
jeff.vance@verilab.com
