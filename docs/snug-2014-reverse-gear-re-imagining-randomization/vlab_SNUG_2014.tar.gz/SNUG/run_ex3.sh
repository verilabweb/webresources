#!/bin/sh
\rm -rf csrc simv.daidir simv
echo "=================== Showing difference between std::randomize and class.randomize() ================"
vcs -sverilog -R revrand_ex.sv
