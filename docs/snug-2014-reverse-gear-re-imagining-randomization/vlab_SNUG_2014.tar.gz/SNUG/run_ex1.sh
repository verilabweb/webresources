#!/bin/sh
\rm -rf csrc simv.daidir simv
echo "=================== Showing randomization to reconstruct the metadata in a Packet ================"
vcs -sverilog -R rev_packet.sv
