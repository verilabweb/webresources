#!/bin/sh
\rm -rf csrc simv.daidir simv
echo "=================== Showing the message examples with three scenarios  ================"
vcs -sverilog -R reverse_rand.sv
