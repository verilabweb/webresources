#!/bin/sh
\rm -rf csrc simv.daidir simv
echo "=================== Showing randomization of all properties and then a subset ================"
vcs -sverilog -R rand_arr.sv
