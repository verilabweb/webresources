#!/usr/bin/env python
# ===================================================================
# Copyright (c) 2002-2005, Verilab Ltd.
# License terms as per doc/License.txt in the vzDoc distribution.
# ===================================================================

__version__ = "$Revision: 723 $"[11:-2]
__doc__ = """
???ToDo
"""

import os,re,string,sys

import vzDoc_error

# ============================================================
class PathManager:
    """
    ???ToDo
    """
    # ........................................................
    def __init__(self, lang, ifile1, ctrl):
        self._lang    = lang
        self._ctrl    = ctrl

        self._path_cache = {}   # maps file basenames to full pathnames;
				# save continual looking up along path...

        self.workingDir       = os.getcwd()
        self.topFileDir       = os.path.normpath(os.path.abspath(os.path.dirname(ifile1)))
        self.docDir           = os.path.join(self.topFileDir, "vzDoc")
        self.parserDir        = os.path.join(self.docDir, "parser")
        self.preprocessorDir  = os.path.join(self.docDir, "preprocessor")

        if self._ctrl.debugging(63):
           print "pathManager.__init__().workingDir = " + self.workingDir
           print "pathManager.__init__().topFileDir = " + self.topFileDir
           print "pathManager.__init__().docDir = " + self.docDir
           print "pathManager.__init__().parserDir = " + self.parserDir
           print "pathManager.__init__().preprocessorDir = " + self.preprocessorDir

        self._initCreateDirs()
	self.pathDirs = [] # keep pychecker happy
        self._initSetUpSearchPath()

    # ........................................................
    def _initCreateDirs(self) :
     if not os.path.exists(self.docDir) :
       os.mkdir(self.docDir)
     if not os.path.exists(self.parserDir) :
       os.mkdir(self.parserDir)
     if not os.path.exists(self.preprocessorDir) :
       os.mkdir(self.preprocessorDir)

    # ........................................................
    def _initSetUpSearchPath(self) :
       (pathvar, self.pathDirs) = self._ctrl.langPath()

       if pathvar == None:
           #print >> sys.stderr, "WARNING -", pathvar, "not defined"
           self.pathDirs = []

       elif len(self.pathDirs) == 0:
           print >> sys.stderr, "WARNING -", pathvar, "is not set to anything useful"

       if self._ctrl.debugging(63):
          print "pathManager.__init__().pathDirs = " + str(self.pathDirs)

    # ........................................................
#     def _initCheckTopFileExists(self) :
#         if self.get_full_path(sys.argv[1]) == None :
#             raise vzDocException("Couldn't find top level file '" + sys.argv[1] + "' in search path")

    # ........................................................
    def findInPath(self, filename, importingFile=None) :
        """
        NB: was get_full_path

        Er, uh, return None if it fails to find anything;
        (better if it raises an exception ?)
        """
        assert(len(filename) > 0)

        #print "CALL:get_full_path(filename = '"+filename+"',\n" + \
        #      "                   importingFile = '"+str(importingFile)+"')"

        if filename[0] == "/" : # absolute...
            return self._set_path_cache(filename)

        try:
            return self._get_path_cache(os.path.basename(filename))
        except vzDoc_error.VzDocNoSuchPath:
            pass # we'll do the work now, then...

        if importingFile != None :
           importingDir = [ os.path.dirname(importingFile) ]
        else :
           importingDir = []

        # This defines the search algorithm
        # TBD Needs to be split into language dependent/independent stuff
        allSearchDirs = [self.topFileDir] + self.pathDirs + importingDir + [self.workingDir]

        for dir in allSearchDirs :
            full_name = os.path.join(dir, filename)
            if os.path.isfile(full_name) :
                #print "RETN:get_full_path(filename = '"+filename+"',\n" + \
                #      "                   importingFile = '"+str(importingFile) + "')\n" + \
                #      "     ->full_name = '" + full_name + "'"
                return self._set_path_cache(full_name)

        print >> sys.stderr,"WARNING - Couldn't find file '" +  filename + "' in search path"

        # For file not found in search path, emit warning but try and carry on rather than give up
        #raise vzDoc_error.VzDocNotInPath,filename
        return None

    # ........................................................
    def _set_path_cache(self, filename):
        assert(filename[0] == '/')
        self._path_cache[os.path.basename(filename)] = filename
        return filename

    # ........................................................
    def _get_path_cache(self, basename) :
        try:
            return self._path_cache[basename]
        except KeyError:
            raise vzDoc_error.VzDocNoSuchPath, basename

    # ........................................................
    def get_doc_dir(self) :
        return self.docDir

    # ........................................................
    def get_code_html_full_path(self, filename) :
        html_full_path = os.path.join(self.get_doc_dir(), os.path.basename(filename) + ".html")
        #print >> sys.stderr, 'f=%s,html_full_path=%s'%(filename,html_full_path)
        return html_full_path

    # ........................................................
    def get_main_index_html(self):
	return os.path.join(self.get_doc_dir(), "index.html")

    # ........................................................
    def get_vzdoc_css(self):
	return os.path.join(self.get_doc_dir(), "vzDoc.css")

    # ........................................................
    def get_all_defs_frame_html(self):
        html_name = self.get_all_frame_html()
	return os.path.join(self.get_doc_dir(), html_name)

    def get_all_frame_html(self):
        if self._lang == 'specman': # Includes units
	    return 'all-structs-frame.html'
        elif self._lang == 'vera':
	    return 'all-classes-frame.html'
        elif self._lang == 'vhdl': # Design Units include Entity/Architecture, Package/Body, Component...
	    return 'all-designunits-frame.html'
        raise 'panic pathman'

    # ........................................................
    def get_use_html(self,usename):
        usefile = string.replace(usename, " ", "__") + ".html"
        return os.path.join(self.get_doc_dir(), usefile)

    # ........................................................
    def get_preprocessor_dir(self) :
      return self.preprocessorDir

    # ........................................................
    def get_preprocessor_base(self, filename) :
      return os.path.join(self.get_preprocessor_dir(), os.path.basename(filename))

    # ........................................................
    def get_preprocessed_filename(self, filename) :
      return (self.get_preprocessor_base(filename) + ".pp")

    # ........................................................
    def get_preprocessed_errors_filename(self, filename) :
      return (self.get_preprocessed_filename(filename) + ".errors")

    # ........................................................
    def get_no_line_cont_filename(self, filename) :
      return (self.get_preprocessor_base(filename) + ".no_line_cont")

    # ........................................................
    def get_code_segs_filename(self, filename) :
      return (self.get_preprocessor_base(filename) + ".code_segments")

    # ........................................................
    def get_no_comments_filename(self, filename) :
      return (self.get_preprocessor_base(filename) + ".no_comments")

    # ........................................................
    def get_parser_dir(self) :
      return self.parserDir

    # ........................................................
    def get_parser_base(self, filename) :
      return os.path.join(self.get_parser_dir(), os.path.basename(filename))

    # ........................................................
    def get_parsed_filename(self, filename) :
      return (self.get_parser_base(filename) + ".out")

    def get_parsed_filename_HACKED(self, filename):
      fn = self._ctrl.useTweakedParserOutput()
      if fn == None:
	  return self.get_parsed_filename(filename)
      print >> sys.stderr, "TEST_MODE : Forcing parser o/p file =", fn
      return fn

    # ........................................................
    def get_parsing_debug_filename(self, filename) :
      return (self.get_parser_base(filename) + ".out.debug")

    # ........................................................
    def get_big_xml_filename(self, filename) :
      return (self.get_parser_base(filename) + ".xml")

    # ........................................................
    def get_relative_path(self, from_file, to_file) :
      """
      Given 2 filenames, derives a relative path to get from one
      directory to another file. e.g. for getting a hyperlink right.
      """
      #print >> sys.stderr, "get_relative_path(from_file = '" + from_file + "', to_file = '" + to_file, "') call"

      from_dir = os.path.dirname(from_file)
      to_dir = os.path.dirname(to_file)
      commonprefix = os.path.commonprefix([from_dir, to_dir])
      #print "commonprefix = '" + commonprefix + "'"
      from_dir_unique = string.replace(from_dir, commonprefix, "")
      #print "from_path_unique = '" + from_dir_unique + "'"
      to_dir_unique = string.replace(to_dir, commonprefix, "")
      #print "to_path_unique = '" + to_dir_unique + "'"

      # Substitute ".." for each dir_name to go up directory hierarchy
      if from_dir_unique == "" :
          up_dirs = "./"
      else :
          up_dirs = string.join(["../"] * (len(string.split(from_dir_unique, "/")) ), "/")

      #print "up_dirs = '" + up_dirs + "'"
      relative_path = os.path.normpath(up_dirs + "/" + to_dir_unique + "/" + os.path.basename(to_file))

      #print >> sys.stderr, "get_relative_path(from_file = '" + from_file, "' + to_file = '" + to_file, "') return '" + relative_path + "'"
      return relative_path

    # ........................................................
    def delete_temp_dirs(self):
      vzdoc_dir = self.get_doc_dir()
      preprocessor_dir = os.path.join(vzdoc_dir, 'preprocessor')
      parser_dir       = os.path.join(vzdoc_dir, 'parser')
      import shutil
      if os.path.exists(preprocessor_dir): shutil.rmtree(preprocessor_dir)
      if os.path.exists(parser_dir):       shutil.rmtree(parser_dir)

    # ........................................................
    def magicallyExpandedFilename(self, fn) :
        """
        And when we say 'magic', we mean it...
        """
        assert(self._lang == 'specman')

        # first, make sure we have the right suffix - if there's no . suffix in the filename
        # then it should be a .e file
        if self._lang == 'specman':
           if '.' not in os.path.basename(fn) :
              fn = fn + ".e"

#            if fn[-2:] != '.e':
#                fn = fn + '.e'

	fn = _sub_delimited(fn)

        # and all the non-delimited ones... one at a time:
        while "$" in fn :
            fn = _sub_nondelimited(fn)

        return fn

# ============================================================
DOLLAR_REGEXP = re.compile(r'\${(.+?)}')

def _sub_delimited(fn) :
    """e.g. ${TESTDIR}/packet.e"""

    to_subs = re.findall(DOLLAR_REGEXP, fn)
    if to_subs == None : return fn

    for ts in to_subs :
        try :
          envvar = os.environ[ts]
          fn = string.replace(fn, "${"+ts+"}", envvar)
        except KeyError:
          print >> sys.stderr, "WARNING : Couldn't find environment variable for substitution into " + fn + " - using ''"

    return fn

def _sub_nondelimited(fn) :
    """
    e.g. $BUILD_PREFIXtest/config.e - where's the substitution exactly?

    ToDo: I think this is too dodgy and should be deleted. partain 2002/05

    """
    dollar_i = string.find(fn,'$')
    assert(dollar_i >= 0)
    dollar_i = dollar_i + 1 # skip past the $ ...

    # look *backwards* for a match; longest wins ...
    for end_i in range(len(fn), dollar_i, -1) :
        poss_sub = fn[dollar_i : end_i]
        try:
            return string.replace(fn, "$"+poss_sub, os.environ[poss_sub])
        except KeyError: pass

    # Oh dear, no idea what to substitute:
    raise vzDoc_error.VzDocNoEnvVarMatch,fn

# ============================================================
