# ===================================================================
# Copyright (c) 2002-2005, Verilab Ltd.
# License terms as per doc/License.txt in the vzDoc distribution.
# ===================================================================
import re, string, sys

from AbbreviatedMatchClass import AbbreviatedMatch

class RegularMatch :

    whitespaceRegexp = re.compile("\s+")

    def __init__(self, dbg, matchString) :
        """Initialises a fairly regular match string - e.g. "send packet", adding a fairly flexible
        interpretation of how to match whitespace"""
        self.dbg = dbg
        self.matchString = matchString
#        print >> sys.stderr,'matchString=<<',matchString,'>>'
        if re.sub(RegularMatch.whitespaceRegexp, "", matchString) == "" : # if nothing more than whitespace
            self.matchStringRegexp = re.compile("\s*")
        else :
            # Replace whitespace by any amount of whitespace, and should not start with an alphanumeric
            matchStringWithWhitespace = "\W(" + re.sub(RegularMatch.whitespaceRegexp, R"\s+", matchString) + ")"
            self.matchStringRegexp = re.compile(matchStringWithWhitespace, re.M)

    def getType(self) :
        return "FullMatch"

    def findFirst(self, file) :
        """Find the first incidence of the matchString, and return a start and end position tuple for the match"""
        methodString = "RegularMatch.findFirst(file)"
        self.dbg.methodCall(methodString, "'"+file+"'")

        matchObject = re.search(self.matchStringRegexp, file)
        assert matchObject != None, "Unsuccessfully tried to find '" + self.matchString + "' in file '" + file + "'"

        # the +1 was, uh, empirically determined (partain, 2002.09)
        start = matchObject.start(0) + 1
        end   = matchObject.end(0)

#        print >>sys.stderr,'findFirst=',start,end,file[start:end]

        self.dbg.methodReturn(methodString, str((start,end)))
        return (start, end)


    def eat(self, file) :
        """Returns the end position of the match if matchString is the next in the file, else return None"""

        methodString = "RegularMatch.eat(file)"
        self.dbg.methodCall(methodString, "'"+file+"'")

        matchObject = re.match(self.matchStringRegexp,file)
        try :
            end =  matchObject.end(0)
        except :
            end = None

        self.dbg.methodReturn(methodString, str(end))
        return end




class DefineMacroReplacer :


    def __init__(self, dbg) :
        self.dbg = dbg
        self.abbreviatedSectionRegexp = re.compile("({\.\.\.}|\[\.\.\.\]|\(\.\.\.\)|\"\.\.\.\")")



    def replace(self, file, replacementMap) :
        """
        This takes a file as a string - which is code that has had everything preprocessed out of it
        except for define macros. And it also takes a replacement map which is an ordered
        list of tuples (pairs) that show what is to be matched and what it should be replaced
        by. e.g. [ ["issue packet {...}", "gen cur_packet keeping {...}"], ["do stuff", "stuff replacement"] ]
        It returns a new string which has had all the relevant stuff replaced.
        Any item in the replacement map must have two strings in it.
        """

        for replacement in replacementMap :
#            print >> sys.stderr, 'replacement file=<<',file,'>>'
            file = self.doSingleReplacement(file, replacement)

#        print >> sys.stderr, 'replacement file finally=<<',file,'>>'
        return file



    def doSingleReplacement(self, file, replacement) :
        """Do a single macro replacement somewhere in the file, where the replacement looks something
        like ["issue packet {...}", "gen cur_packet keeping {...}"]"""

        methodString = "DefineMacroReplace.doSingleReplacement(file, replacement)"
        self.dbg.methodCall(methodString, "'" + file + "', " + str(replacement))

        assert len(replacement) == 2, \
               """Macro define replacement request is not in format of ["<matchString>", "<replacementString>"]"""

        # We need to split up the match into regular match items like 'issue packet' which can be
        # done with a regexp and abbreviated match items such as '{...}' which need a custom algorithm

        matchList       = re.split(self.abbreviatedSectionRegexp, replacement[0])
        replacementList = re.split(self.abbreviatedSectionRegexp, replacement[1])

        # Create objects of type abbreviated match ("{...}") or full match ("send packet") to use as match
        # servers for the algorithm - which should operate in a universal way independent of the type

        macroMatchList = []
        for matchSection in matchList :
            if re.match(self.abbreviatedSectionRegexp, matchSection) :
                macroMatchList.append(AbbreviatedMatch(self.dbg, matchSection))
            else :
                macroMatchList.append(RegularMatch(self.dbg, matchSection))

        startAndEndPositionList = self.getStartAndEndPositions(file, macroMatchList)
        newFile = self.makeChanges(file, startAndEndPositionList, replacementList)

        self.dbg.methodReturn(methodString, newFile)
        return newFile



    def getStartAndEndPositions(self, file, macroMatchList) :
        """ Returns a list of (start,end) items the same size as macroMatchList that shows where
        each of the macroMatchList items matched in the file (but all in one place)"""

        methodString = "DefineMacroReplace.getStartAndEndPositions(file, macroMatchList)"
        self.dbg.methodCall(methodString, "'" + file + "', " + str(macroMatchList))

#        print >> sys.stderr,'getStartAndEnd; macromatch=',`map(lambda m:m.matchString, macroMatchList)`,'file=',`file`

        states = len(macroMatchList)
        fileIndex = 0                 # Shows which character index we're up to in the file
        state = 0                     # Shows which match item in the matchList we're hoping to match next
        currentTryIndex = 0           # Stores the fileIndex for the current attempt at matching
        startEnd = states * [()]      # Will hold (start,end) positions of the text that matched

        # Here we go with the state machine that advances to the next section on a match, but
        # resets if it doesn't get the next thing expected. There should always be a match somewhere
        # in the file - or else something has gone wrong.

        filelen = len(file)

        while state < states and currentTryIndex < filelen :
#            print >>sys.stderr, 'state=',state,'currentIndex=',currentTryIndex
            matchObject = macroMatchList[state]
            if state == 0 :
                (start, end) = matchObject.findFirst(file[currentTryIndex:])
                startEnd[state] = (currentTryIndex+start, end)
                fileIndex = currentTryIndex + end
#                print >>sys.stderr,'start end=',start,end,'fileindex=',fileIndex
                state = 1
            else :
                end = matchObject.eat(file[fileIndex:])
                if end == None :
                    currentTryIndex = currentTryIndex + start + 1   # Reset state machine and try again
                    state = 0
#                    print >>sys.stderr,'reset'
                else :
                    startEnd[state] = (fileIndex, fileIndex+end)
                    fileIndex = fileIndex + end             # Advance file position
                    state = state + 1                       # Advance state
#                    print >>sys.stderr,'state=',state,'start end=',start,end,'fileindex=',fileIndex

        assert state == states

        self.dbg.methodReturn(methodString, str(startEnd))
#        print >> sys.stderr,'startEnd=',`startEnd`

        return startEnd



    def makeChanges(self, file, startAndEndPositionList, replacementList) :
       """Go through the file removing the sections delimited by the start
       and end position, and substituting it with the respective replacement.
       If the replacement is an abbreviated match type, dont replace."""

       methodString = "DefineMacroReplace.makeChanges(file, startAndEndPositionList, replacementList)"
       self.dbg.methodCall(methodString, "'" + file + "'" + str(startAndEndPositionList) + str(replacementList))

#       print >>sys.stderr, 'makeChanges: startend=',`startAndEndPositionList`,'repllist=',`replacementList`,'file=',`file`

       #for slice in startAndEndPositionList :
       #    (start, end) = slice
       #    print "'" + file[start:end] + "'"

       assert len(startAndEndPositionList) == len(replacementList)

       adjustment = 0
       section = 0
       for section in range(len(replacementList)) :
           (start, end) = startAndEndPositionList[section]
           start = start + adjustment
           end = end + adjustment
           if not self.isAbbreviatedSection(replacementList[section]) :
               replacement = " " + replacementList[section] + " "
               replacement = self.massageReplacement(replacement)
               #file = file[:start] + file[end:]
               file = file[:start] + replacement + file[end:]
               adjustment = adjustment + len(replacement) - (end-start)

       self.dbg.methodReturn(methodString, file)
       return file


    def isAbbreviatedSection(self, string) :
        return re.match(self.abbreviatedSectionRegexp, string)


    def massageReplacement(self, replacement) :
        """ For a single (non-abbreviated) replacement - catch all those horrible little things that
        trace reparse doesn't show as syntactically correct constructs - Arrgh - horrible stuff"""
        replacement = string.replace(replacement, "\n", " ")
        if string.lstrip(replacement) != "" and \
           string.lstrip(replacement)[0] == "{" and string.rstrip(replacement)[-1] == "}":
              replacement = re.sub("^\s*({)", "", replacement)
              replacement = re.sub("(})\s*$", "", replacement)

        massaged_replacement = re.sub("([^{])}", "\\1;}", replacement)
        # Do this until no change, due to overlapping occurrences
        while massaged_replacement != replacement :
            replacement = massaged_replacement
            massaged_replacement = re.sub("([^;{])}", "\\1;}", replacement)

        return massaged_replacement


