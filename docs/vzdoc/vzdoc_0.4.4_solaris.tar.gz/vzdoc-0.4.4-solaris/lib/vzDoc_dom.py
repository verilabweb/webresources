#!/usr/bin/env python
# ===================================================================
# Copyright (c) 2002-2005, Verilab Ltd.
# License terms as per doc/License.txt in the vzDoc distribution.
# ===================================================================

__version__ = "$Revision: 723 $"[11:-2]
__doc__ = """
???ToDo
"""

import string,sys

from xml.dom import core

import vzDoc_error
#import vzDoc_util

# ============================================================
def getChildrenOfType(node, tag) :
    """
    For a particular DOM node, return a list of all the child nodes in
    the whole of the hierarchy below it that have a particular
    tag. (depth in private version is just used for debug prettifying)

    e.g. struct_list = getChildrenOfType(file_node, "STRUCT_ID")
    """
    return __gcotype(node, tag, 0)

def __gcotype(node, tag, depth) :
    #print "  "* depth, "getChildrenofType(", node, ", ", tag, ")"
    #print "nodeName : ", node.nodeName, "nodeValue, ", node.nodeValue
    result_list = []
    if node.nodeName == tag :
        result_list.append(node)
    if node.hasChildNodes() :
        for cnode in  node.childNodes :
           result_list = result_list + __gcotype(cnode, tag, depth+1)
    #print "  "*depth, result_list
    return result_list

# ............................................................
def getChildNodes(node, tag) :
    """
    For a particular DOM node, return a list of all child nodes that
    match the specified tag.
    """
    child_list = []
    if node.nodeName == tag :
        child_list.append(node)
    elif node.childNodes != None :
        for cnode in node.childNodes :
            cnode_list = getChildNodes(cnode, tag)
            if cnode_list != None :
                child_list = child_list + cnode_list
    return child_list

# ............................................................
def getFirstChildNode(node, tag) :
    """
    For a particular DOM node, return the first child node that
    matches the specified tag

    Return None if there is no such child node.
    """
    # ToDo: partain -- not too happy w/ this 'return None' thing

    #print "getFirstChildNode ", node, tag,
    if node.nodeName == tag :
        #print "returning node : ", node
        return node
    elif node.childNodes != None :
        # Search child nodes and return a node or None
        for cnode in node.childNodes :
            firstChildNode = getFirstChildNode(cnode, tag)
            if firstChildNode != None :
                #print "returning cnode : ", firstChildNode
                return firstChildNode
    #print "returning None"
    return None

# ............................................................
def getFirstChildText(node, tag) :
    """
    For a particular DOM node, return the text of the first child node
    that matches the specified tag. The tag is assumed to directly
    contain a text node.

    e.g. scalar_text = getFirstChildText(field_node, "SCALAR_TYPE_ID")

    If there is no such child node, or if the child node is not
    text, return None.
    """
    firstChildNode = getFirstChildNode(node, tag)
    if firstChildNode != None :
        for child in firstChildNode.childNodes :
            if child.nodeType == core.TEXT_NODE :
                return child.nodeValue

    return None # ToDo: partain: I'm not really happy with this 'return None' thing

# ............................................................
def getEnclosingFilename(node) :
    parent_file_node = getParentNode(node, "FILE")
    parent_filename = getFirstChildText(parent_file_node, "FILENAME")
    assert(parent_filename != None)
    return parent_filename

def getFilename(node, tag) :
    """
    For a particular DOM node, return the filename of the child
    element matching the tag.

    e.g. filename = getFilename(node, "FIELD_DECLARATION_ID")

    Raises an exception if there is no such thing.
    """
    firstChildNode = getFirstChildNode(node, tag)
    if firstChildNode != None:
        attrs = firstChildNode.attributes
        for i in range(0, attrs.get_length()) :
            #print attrs.item(i).name, attrs.item(i).value
            if attrs.item(i).name == "file" :
                return attrs.item(i).value

    prtNode(sys.stderr,node)
    raise vzDoc_error.VzDocNoFilenameInNode,('tag=%s,node=%s'%(tag,`node`))

def prtNode(fd,node) :
    print >> fd, "node", id(node), node,
    print >> fd, "node.nodeName :", node.nodeName,
    print >> fd, "node.nodeValue : ", node.nodeValue,
    print >> fd, "node.childNodes", node.childNodes,
    print >> fd, ''

# ............................................................
def getLineNumber(node, tag) :
    """
    For a particular DOM node, return the line number of the child
    element matching the tag.

     e.g. line_number = getLineNumber(node, "FIELD_DECLARATION_ID")

    Return None if there is no such element, or if we cannot
    determine the line number of the element that we do find.

    """
    # ToDo: partain -- not too happy w/ this 'return None' thing

    firstChildNode = getFirstChildNode(node, tag)
    if firstChildNode != None :
        attrs = firstChildNode.attributes
        for i in range(0, attrs.get_length()) :
            #print >> sys.stderr, attrs.item(i).name, attrs.item(i).value
            if attrs.item(i).name == "line" :
                return attrs.item(i).value
    return None

# ............................................................
def getParentNode(node, tag) :
    """
    For a particular DOM node, return the parent node that matches the
    specified tag.

    Return None if no such node exists
    """
    # ToDo: partain -- not too happy w/ this 'return None' business

    if node.parentNode.nodeName == tag :
        return node.parentNode
    elif node.parentNode == None :
        return None
    else :
        return getParentNode(node.parentNode, tag)

# ............................................................
def getText(node) :
    """
    For a DOM node, return all the text underneath the node.

    If there is *no* text underneath, return None.
    """
    # ToDo: change the None case to an exception if we do elsewhere

    if node.nodeType == core.TEXT_NODE :
        return node.nodeValue
    elif node.nodeType == core.ELEMENT_NODE :
        stuff = []
        for cnode in node.childNodes :
            nodetext = getText(cnode)
            if nodetext != None:
                stuff.append(nodetext)
	if len(stuff) > 0:
            return string.join(stuff,'')
    return None

# ............................................................
def get_sorted_node_list(node_list, id_type) :
    """
    Given a node list, and a name of the type of id_name we're
    interested in, return a sorted list of the id_names of those nodes
    and a dir to key the nodes.

    NOTE: you can have the same ids in multiple files, so the
    'dir' things have to be *lists*.
    """
    node_name_list = []
    node_dir = {}
    for node in node_list :
        id_name = getFirstChildText(node, id_type)
        assert(id_name != None)
        if not node_dir.has_key(id_name):
            node_dir[id_name] = []
            node_name_list.append(id_name) # no dups on this list, please
        node_dir[id_name].append(node)

    node_name_list.sort()
    return (node_name_list, node_dir)

# ============================================================
