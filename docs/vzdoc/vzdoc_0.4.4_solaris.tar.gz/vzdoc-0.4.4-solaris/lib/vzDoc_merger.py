#!/usr/bin/env python
# ===================================================================
# Copyright (c) 2002-2005, Verilab Ltd.
# License terms as per doc/License.txt in the vzDoc distribution.
# ===================================================================

__version__ = "$Revision: 723 $"[11:-2]
__doc__ = """
???ToDo
"""

import re,string,sys

from xml.dom.sax_builder import SaxBuilder
from xml.sax import saxexts, saxlib, saxutils
from xml.sax.drivers import drv_xmlproc

import vzDoc_dom
import vzDoc_util
import DebugClass
import InheritanceTreeClass

# ============================================================
def Merger(lang=None, pathman=None, ctrl=None, inheritance_tree=None): # NB: the singleton trick
    if _Merger._instance == None:
        if lang == None or pathman == None or ctrl == None or inheritance_tree == None: raise 'Merger:panic' # assert
	_Merger._instance = _Merger(lang, pathman, ctrl, inheritance_tree)
    return _Merger._instance

class _Merger:
    """
    ???
    """

    _instance = None # used above

    # ........................................................
    def __init__(self, lang, pathman, ctrl, inheritance_tree):
        self._lang    = lang
        self._pathman = pathman
        self._ctrl    = ctrl
        self._inheritance_tree = inheritance_tree
    # ........................................................
    def go(self, ifile1, pfiles):
        """
        Main routine for the class.
        """
        if self._ctrl.verbose():
            print >> sys.stderr, 'Merging into XML and creating a DOM...'

        # merge everything into one big xml file:
        xmlfn = self.merge_xml(ifile1, pfiles)

        # construct a DOM for that:
        dom = self.build_dom(xmlfn)

        # gather interesting things from the DOM:
        (defs, defs_to_display, uses) = self.harvest_dom(dom)

        return (defs, defs_to_display, uses)

    # ........................................................
    XML_REGEXP    = re.compile(r'(<FILE.*</FILE>)', re.DOTALL)
    FILE_REGEXP   = re.compile(r'<FILE(.*?)>')
    MOVE_REGEXP   = re.compile(r'(<[^/]\w+)><!--( line=.*?)-->')
    DELETE_REGEXP = re.compile(r'(<!-- line=.*?-->)')
    # NB: the line=.* is really: line=.* file=.*

    def merge_xml(self, ifile1, pfiles):
        """
        Merge all the XML from the parsed files into one big XML file.
        Each parser output file contains (amongst other things) an XML
        representation of the input file, delimited by <FILE>...</FILE>
        xml tags and containing contains info on which file that section
        of XML was generated from.  So pick out all the XML from each
        parser output file and concatenate it into one big XML file,
        wrapping it all in another top level tag to make it one XML
        document

        We also need to move any line number comments from their place at
        the front of id names to a line attribute associated with the ID
        tage itself. e.g.

        <STRUCT_ID><!-- line="23" -->packet</STRUCT_ID>

        becomes

        <STRUCT_ID line="23">packet</STRUCT_ID>
	"""
        pathman = self._pathman

        xml_filename = pathman.get_big_xml_filename(ifile1)

        xmlf = open(xml_filename, 'w')
        xmlf.write('<?xml version="1.0"?>\n<FILESET>\n')

        # print >> sys.stderr, 'pfiles=',pfiles

        for pfn in pfiles:
            poutfn = pathman.get_parsed_filename_HACKED(pfn)
            whole_file = vzDoc_util.read_file_into_string(poutfn)

            xml_stuff = re.findall(_Merger.XML_REGEXP, whole_file)

	    #print >> sys.stderr, 'file=',whole_file
            assert(len(xml_stuff) == 1)
            # if this fails, then something went wrong with
            # checking for errors in the parser.

            goods = xml_stuff[0]
            #print >> sys.stderr, 'pfile=',pfn,'wholefile=',whole_file,'\ngoods=',goods
            goods = re.sub(_Merger.FILE_REGEXP
			  , "<FILE\\1><FILENAME>%s</FILENAME>" % pfn
                          , goods)
            goods = re.sub(_Merger.MOVE_REGEXP,  r'\1\2>', goods)
            goods = re.sub(_Merger.DELETE_REGEXP, '',      goods)
            xmlf.write(goods)
            xmlf.write("\n")

        xmlf.write("</FILESET>\n")
        xmlf.close()

        return xml_filename # so the next guy will know where to find it!

    # ........................................................
    def build_dom(self, xml_fn):
	"""
        Parse the big XML document into a DOM object. Ripped straight
        out of "XML processing with Python" book page 314 (+ an error
        handler got from www.python.org browsing)
	"""
        #print "Analysing ..."
	#print "Parsing XML into DOM object ...."
	#p = saxexts.make_parser()
        p = drv_xmlproc.create_parser()
        dh = SaxBuilder()
        p.setDocumentHandler(dh)
        p.setErrorHandler(saxutils.ErrorRaiser())
        p.parse(xml_fn)
        dom_doc = dh.document
        return dom_doc

    # ........................................................
    def harvest_dom(self, dom):
        """
        We collect:
        (a) all the things tagged by STRUCT_ID (no duplicates, sorted)
        (b) a table of all the *uses* of those STRUCT_IDs in
	    "statements" of various kinds.
        """
        struct_ids = {}
        for sid in map(vzDoc_dom.getText, dom.getElementsByTagName("STRUCT_ID")):
            if struct_ids.has_key(sid): continue
            struct_ids[sid] = 1

        if self._lang == 'vhdl': # A hack - add ENTITY_ID and PACKAGE_ID things
            for sid in map(vzDoc_dom.getText, dom.getElementsByTagName("STRUCT_ID")):
                if struct_ids.has_key(sid): continue
                struct_ids[sid] = 1
            for sid in map(vzDoc_dom.getText, dom.getElementsByTagName("STRUCT_ID")):
                if struct_ids.has_key(sid): continue
                struct_ids[sid] = 1

	sorted_struct_ids = struct_ids.keys()
        if self._lang == 'specman':
            sorted_struct_ids.sort(cmp_structs)
        else: # an ordinary sort will do
            sorted_struct_ids.sort()

        #print >> sys.stderr, 'sorted struct_ids:',`sorted_struct_ids`

        # . . . . . . . . . . . . . . . . . . . . . . . . . . .
        stmt_types = [ 'STRUCT_STATEMENT' ] # all languages
        if self._lang == 'specman':
            stmt_types.append('EXTEND_STRUCT_STATEMENT')
            stmt_types.append('UNIT_STATEMENT')

        if self._lang == 'vhdl':
            stmt_types.append('PACKAGE_DECLARATION')
            stmt_types.append('ENTITY_DECLARATION')

        # we collect all these "statement" things into buckets,
        # divided according to the STRUCT_IDs that we collected before.
        # I.e. we are building up a two-level table that says where
        # every symbol is *used*.
        struct_id_uses = {}
        for sid in sorted_struct_ids: # initializing
            struct_id_uses[sid] = []

        for stype in stmt_types:
            for snode in dom.getElementsByTagName(stype):
                struct_id = vzDoc_dom.getFirstChildText(snode, "STRUCT_ID")
                assert(struct_id != None)
                struct_id_uses[struct_id].append(snode)
                self.update_inheritance_tree(snode)


	sorted_struct_ids_to_display = sorted_struct_ids
            
        if self._lang == 'vera':
            # Add all the global enums and ports to the list of
            # potential hyperlinked ids
            newlist = sorted_struct_ids[:]

            for name in get_vera_global_ports_and_enums(dom.getElementsByTagName("STRUCT_STATEMENT")):
                newlist.append("_Global." + name)

            sorted_struct_ids = newlist

        if self._lang == 'specman':
            # Add all the global typedefs to the list of
            # potential hyperlinked ids
            newlist = sorted_struct_ids[:]

            for name in get_specman_global_typedefs(dom.getElementsByTagName("STRUCT_STATEMENT")):
                newlist.append("_Global." + name)

            sorted_struct_ids = newlist

        return (sorted_struct_ids,sorted_struct_ids_to_display,struct_id_uses)

    # ........................................................
    def update_inheritance_tree(self, snode) :
        struct_id  = vzDoc_dom.getFirstChildText(snode, "STRUCT_ID")
        assert(struct_id != None)
        extends_id = vzDoc_dom.getFirstChildText(snode, "EXTENDS_ID")

        if extends_id == None :
            self._inheritance_tree.addClass(struct_id)
        else :
            self._inheritance_tree.addSubClass(struct_id, extends_id)

        field_nodes  = vzDoc_dom.getChildNodes(snode, "FIELD_DECLARATION")
	(id_name_list, node_dir) = vzDoc_dom.get_sorted_node_list(field_nodes, "FIELD_DECLARATION_ID")
        for id_name in id_name_list :
            self._inheritance_tree.addField(id_name, struct_id)
            
        method_nodes = vzDoc_dom.getChildNodes(snode, "METHOD_DECLARATION")
	(id_name_list, node_dir) = vzDoc_dom.get_sorted_node_list(method_nodes, "METHOD_NAME_ID")
        for id_name in id_name_list :
            self._inheritance_tree.addMethod(id_name, struct_id)

        event_nodes  = vzDoc_dom.getChildNodes(snode, "EVENT_DECLARATION")
	(id_name_list, node_dir) = vzDoc_dom.get_sorted_node_list(event_nodes, "EVENT_ID")
        for id_name in id_name_list :
            self._inheritance_tree.addEvent(id_name, struct_id)
        
        
        
# ============================================================
def get_vera_global_ports_and_enums(nodes):
    """
    NB: vera only

    Get a list of all the global enum and port names (we're going to
    pretend these are class names such that we can link to them).
    """
    global_members = []

    for node in nodes :

       if vzDoc_dom.getFirstChildText(node, "STRUCT_ID") == "_Global" :

          port_node_list = vzDoc_dom.getChildrenOfType(node, "PORT_DECLARATION")
          for port_node in port_node_list :
              port_name = vzDoc_dom.getFirstChildText(port_node, "PORT_NAME_ID")
              assert(port_name != None)
              global_members.append(port_name)

          enum_node_list = vzDoc_dom.getChildrenOfType(node, "ENUM_DECLARATION")
          for enum_node in enum_node_list :
              enum_name = vzDoc_dom.getFirstChildText(enum_node, "ENUM_NAME_ID")
              assert(enum_name != None)
              global_members.append(enum_name)

    return global_members

# ============================================================
def get_specman_global_typedefs(nodes):
    """
    NB: specman only

    Get a list of all the global typedefs and port names (we're going to
    pretend these are class names such that we can link to them).
    """
    global_members = []

    for node in nodes :

       if vzDoc_dom.getFirstChildText(node, "STRUCT_ID") == "_Global" :

          typedef_node_list = vzDoc_dom.getChildrenOfType(node, "TYPE_STATEMENT")
          for typedef_node in typedef_node_list :
              typedef_name = vzDoc_dom.getFirstChildText(typedef_node, "TYPE_STATEMENT_ID")
              assert(typedef_name != None)
              global_members.append(typedef_name)

    return global_members

# ................................................................
def cmp_structs(a, b):
    """
    A specman 'struct' can be made up of several "words".  The
    last word is the most significant, the next to last
    second-most-significant, and so on.

    This is a comparison routine to feed to python's 'sort'.
    """
    a_pieces = string.split(a,' ')
    b_pieces = string.split(b,' ')
    a_last   = a_pieces[-1]
    b_last   = b_pieces[-1]

    if a_last < b_last:
        return -1
    elif a_last > b_last:
        return 1
    else:
        a_first = a_pieces[0:-1]
        b_first = b_pieces[0:-1]
        if len(a_first) <= 0:
            if len(b_first) <= 0: # both names the same
                return 0
            else: # 'a' ran out first; declare it less than
                return -1
	else: # more 'a' there...
            if len(b_first) <= 0: # b ran out first
                return 1
            else: # they're both still going...
                a_joined = string.join(a_first,' ')
                b_joined = string.join(b_first,' ')
                return cmp_structs(a_joined, b_joined)

# ============================================================
