#!/usr/bin/env python
# ===================================================================
# Copyright (c) 2002-2005, Verilab Ltd.
# License terms as per doc/License.txt in the vzDoc distribution.
# ===================================================================

__version__ = "$Revision: 723 $"[11:-2]
__doc__ = """
???ToDo
"""

import vzDoc_util
import string, re, sys

# ============================================================
def DocCommentManager(lang=None, pathman=None, ctrl=None): # NB: the singleton trick
    if _DocCommentManager._instance == None:
        if lang == None or pathman == None or ctrl == None: raise 'DocCommentManager:panic' # assert
	_DocCommentManager._instance = _DocCommentManager(lang, pathman, ctrl)
    return _DocCommentManager._instance

class _DocCommentManager:
    """
    ???ToDo
    """
    _instance = None # used above


    # ........................................................
    def __init__(self, lang, pathman, ctrl):
        self._lang = lang
        self._pathman = pathman
        self._ctrl = ctrl
        self._cache = {}
        

    # ............................................................
    def shortDocComment(self, filename, id_line_num, id_check_name):
        """Get doc comment up until the first full-stop (period)"""

        doc_comment = self.fullDocComment(filename, id_line_num, id_check_name)

        sentence_list = string.split(doc_comment, ".")
        if len(sentence_list) <= 0: return ''

        short_doc_comment = sentence_list[0]

        if short_doc_comment[:14] == 'No comment':
            # Hmmm... wildly suspicious about this... (partain 2002.05)
            return ''

        if len(sentence_list) > 1:
            short_doc_comment = short_doc_comment + "."

        return short_doc_comment


    # ............................................................
    def fullDocComment(self, filename, id_line_num, id_check_name):
        """
        Get a doc comment from a specified file, with a line that
        indicates the construct where the doc comment finishes
        """

        if self._lang == 'vhdl':
            print >> sys.stderr, 'NB: no doc comments for VHDL yet'
            return ''

        #if debug_level > 0 :
        #print >> sys.stderr, "docComment(filename = '%(filename)s', line = %(id_line_num)s, id_check_name='%(id_check_name)s')" % vars()

        assert(id_line_num != None)
        linen = string.atoi(id_line_num)
        assert(linen > 0)

        # Get the doc_comment from the cache if it's been accessed already
        cache_key = (filename, id_line_num)
        if cache_key in self._cache.keys() :
            return self._cache[cache_key]

        whitespace_regexp  = re.compile("^\s*$")
        if self._lang == 'specman':
            doc_comment_regexp = re.compile("^\s*(//|--)\*")
            comment_regexp     = re.compile("^\s*(//|--)")
	elif self._lang == 'vera':
            start_doc_comment_regexp = re.compile("^\s*/\*\*")
            end_doc_comment_regexp   = re.compile("\*/\s*")
        elif self._lang == 'vhdl':
            doc_comment_regexp = re.compile("^\s*//\*") # ToDo - not yet defined
            comment_regexp     = re.compile("^\s*//")   # ToDo - not yet defined
        else:
            raise 'panic panic panic in docComment'

        filepath = self._pathman.findInPath(filename)
        if filepath == None:
            # this can happen, for example, if some doc-comment-ery
            # is found in (say) rvm_std_lib.vrh but vzDoc doesn't really
            # know where that is.
            return ""

        file = open(filepath)
        line_num = 1
        doc_comment = ""
        in_doc_comment = 0
        line_list = []

        while line_num < linen :

            line = file.readline()
            if not line :
               raise Exception("Read past end of file")
            line_list.append(line)
            line_num = line_num + 1
            if self._lang == 'vera':
                start_doc_comment = re.findall(start_doc_comment_regexp, line) != []
                end_doc_comment   = re.findall(end_doc_comment_regexp, line)   != []
                whitespace_line   = re.findall(whitespace_regexp, line)        != []

                if in_doc_comment :
                   doc_comment = doc_comment + line
                   if end_doc_comment :
                      in_doc_comment = 0
                else :
                   if whitespace_line :
                       pass
                   elif start_doc_comment :
                      doc_comment = line
                      if not end_doc_comment :
                         in_doc_comment = 1
                   elif end_doc_comment :
                      in_doc_comment = 0
                   else :
                      doc_comment = ""

        declaration_line = file.readline()

        # (Go ahead and close the file; we don't use it after this)
        file.close()

        if re.findall(id_check_name, declaration_line) == [] :
            if self._ctrl.verbose():
                vzDoc_util.warning("Didn't find `%s' at appropriate line (%s) of %s"%(
			id_check_name,id_line_num,file.name))
            result = ""
            self._cache[cache_key] = result 
            return result

        if self._lang == 'vera':
            if in_doc_comment :
               vzDoc_util.warning("Unterminated doc comment")

            if doc_comment == "" :
              same_line_doc_comment = self._sameLineDocComment(declaration_line)
              if same_line_doc_comment != None :
                  doc_comment = same_line_doc_comment

            result = self._process_doc_comment(doc_comment)
            self._cache[cache_key] = result             
            return result


	# NB: rest is specman only!
        line_list.reverse()
        in_doc_comment = 0
        doc_comment = ""

        for line in line_list :

            doc_comment_line = re.findall(doc_comment_regexp, line) != []
            comment_line     = re.findall(comment_regexp, line) != [] and not doc_comment_line
            whitespace_line  = re.findall(whitespace_regexp, line) != []
            code_line = not whitespace_line and not (comment_line or doc_comment_line)

#            if debug_level > 1 :
#                print line_num, line,
#                print "doc_comment_line", doc_comment_line, "comment_line", comment_line, \
#                      "whitespace_line", whitespace_line, "code_line", code_line

            if doc_comment_line + comment_line + whitespace_line + code_line != 1 :
                raise Exception("doc_comment detector failure")

            if not in_doc_comment :
                if whitespace_line :
                   pass
                elif comment_line :
                   pass
                elif code_line :
                   doc_comment = ""
                   break
                elif doc_comment_line :
                   in_doc_comment = 1
                   doc_comment = line
                   single_line_doc_comment = line
            else:
                if whitespace_line :
                   doc_comment = single_line_doc_comment
                   break
                elif comment_line :
                   doc_comment = line + doc_comment
                elif code_line :
                   doc_comment = single_line_doc_comment
                   break
                elif doc_comment_line :
                   doc_comment = line + doc_comment
                   break

        if doc_comment == "" :
            same_line_doc_comment = self._sameLineDocComment(declaration_line)
            if same_line_doc_comment != None :
                doc_comment = same_line_doc_comment

        result = self._process_doc_comment(doc_comment)
        self._cache[cache_key] = result             
        return result


    # ............................................................
    def docCommentTags(self, doc_comment):
        spaceless = string.replace(doc_comment," ","")
        match = re.compile(r'^([^: \n]+):').match(spaceless)
        if not match:
            return None
        tags = string.split(match.group(1),",")
        #print >> sys.stderr, 'tags=',`tags`,'doc_comment=',doc_comment
        return tags


    # ............................................................
    def _process_doc_comment(self, doc_comment):
        """
        Process doc_comment - stripping out unnecessary stuff

        NB: varies from language to language
        """
        # print >>sys.stderr, "Process doc comment '", doc_comment, "'"
        if self._lang == 'specman':
            docline_regexp = re.compile("^\s*(//|--)\*+", re.M)
            comment_regexp = re.compile("^\s*(//|--)",    re.M)
            doc_comment = re.sub(docline_regexp, "", doc_comment)
            doc_comment = re.sub(comment_regexp, "", doc_comment)

        elif self._lang == 'vera':
            doc_comment = re.sub("^\s*/\*\*+", "", doc_comment)  # Remove initial /** and any number of *
            doc_comment = re.sub("\*+/\s*$", "", doc_comment)   # Remove terminating */
            doc_comment = re.sub("\n\s*\*?", "\n", doc_comment)  # Remove leading *

        doc_comment = string.strip(doc_comment)
        # if we're left with nothing, then we're done:
        if doc_comment == '': return ''

        # We allow for comments to have an _implicit_ <pre>...</pre> around them
        if self._ctrl.autoPreDocComments():
            doc_comment = '<PRE>'+doc_comment+'</PRE>'

        # Ensure stuff inside <PRE></PRE> isn't mangled
        pre_seg_regexp  = re.compile("(<PRE>.*?</PRE>)", re.M)
        pre_filter_list = re.split(pre_seg_regexp, doc_comment) # separate into <PRE> and not
        for segment in pre_filter_list :
           if segment[:5] != "<PRE>" :      # Change any whitespace to single spaces
              doc_comment = re.sub("\s+", " ", doc_comment)

        doc_comment = string.strip(string.join(pre_filter_list))
        if doc_comment != '':
	    # leading ' ' makes for compat with older golden stuff
	    # trailing \n makes for *slightly* prettier HTML
            doc_comment = ' ' + doc_comment + '\n'
        # print >>sys.stderr, "-> '" + doc_comment + "'"
        doc_comment = self._reformat_doc_comment_tags(doc_comment)
        return doc_comment


    # ............................................................
    def _reformat_doc_comment_tags(self, doc_comment):
        """Looks for @tags in doc comments and reformats them appropriately.
        Tags are assumed to be at the end of doc comments. Params are assumed
        to be grouped together"""
        
        tag_split_regexp = re.compile("(\n\s*@[a-z]+\s+[^@]+(?=@|$))")
        tag_split = re.split(tag_split_regexp,doc_comment)
        doc_comment = ""
        self._first_tag = 1
        self._first_param_tag = 1
        self._first_see_tag = 1
        
        for segment in tag_split :
            if re.match("^\s*@[a-z]+\s+", segment) == None :
                doc_comment = doc_comment + segment
            else :
                if self._first_tag == 1 :
                    doc_comment = doc_comment + "\n<P><dl><dd><dl>\n"
                    self._first_tag = 0
                doc_comment = doc_comment + self._reformat_tag_segment(segment)

        if self._first_tag == 0 :
           doc_comment = doc_comment + "\n</dl></dd></dl>\n"
            
        return doc_comment


    # ............................................................
    def _reformat_tag_segment(self, segment) :

        result = ""
        
        tag_type = re.findall("^\s*(@[a-z]+)\s+", segment)[0]
        segment = string.replace(segment, tag_type, "")
        segment = string.strip(segment)
        
        if   tag_type == "@see" :
            result = self._reformat_tag_segment_see(segment)
        elif tag_type == "@param" :
            result = self._reformat_tag_segment_param(segment)
        elif tag_type == "@return" :
            result = self._reformat_tag_segment_return(segment)
        elif tag_type == "@author" :
            result = self._reformat_tag_segment_author(segment)
        elif tag_type == "@version" :
            result = self._reformat_tag_segment_version(segment)
        else :
            print >> sys.stderr, "Unknown doc comment tag '" + tag_type + "' - leaving unformatted"
            result = segment 
                               
        return result



    # ............................................................
    def _reformat_tag_segment_see(self, segment) :
        if self._first_see_tag == 1 :
            header = "\n<dt><b>See Also:</b>\n<dd>"
            self._first_see_tag = 0
        else :
            header = "\n<dd>"
            
        split_tag = string.split(segment, "#")
        if segment[0] == "<" and segment[-1] == ">" :
            # - Preformatted hyperlink        
            result = segment
        elif len(split_tag) == 2 and split_tag[0] == "" :
            # - #local_member form
            result = '<A HREF="#' + split_tag[1] + '">' + split_tag[1] + '</A>'
        elif len(split_tag) == 2 and split_tag[0] != "" :
            # - remote#member form        
            result = '<A HREF="' + split_tag[0] + '.html#' + split_tag[1] + '">' + split_tag[0] + '.' + split_tag[1] + '</A>'
        elif len(split_tag) == 1 :
            # - remote_class form
            result = '<A HREF="' + split_tag[0] + '.html">' + split_tag[0] + '</A>'
        else :
            # - Don't understand - leave as is
            result = segment
        result = header + result
        return result

    
    # ............................................................
    def _reformat_tag_segment_param(self, segment) :
        if self._first_param_tag == 1 :
            result = "\n<dt><b>Parameters:</b>"
            self._first_param_tag = 0
        else :
            result = ""
        result = result + "<dd>" + string.split(segment)[0] + " - <CODE>" + string.join(string.split(segment)[1:]) + "</CODE>"
        return result


    # ............................................................
    def _reformat_tag_segment_return(self, segment) :
        result = "\n<dt><b>Returns:</b><dd>" + segment
        return result


    # ............................................................
    def _reformat_tag_segment_author(self, segment) :
        result = "\n<dt><b>Author:</b><dd>" + segment 
        return result


    # ............................................................
    def _reformat_tag_segment_version(self, segment) :
        result = "\n<dt><b>Version:</b><dd>" + segment
        return result


    # ............................................................
    def _sameLineDocComment(self, line) :
        """Specman or Vera currently, returns end of line doc comment or None"""
        if self._lang == 'specman' :
           end_of_line_doc_comment_regexp = re.compile("(?://|--)\*(.*?)$")
        elif self._lang == 'vera' :
           end_of_line_doc_comment_regexp = re.compile("/\*\*(.*?)\*/.*$")
#        elif self._lang == 'vhdl' :
#           end_of_line_doc_comment_regexp = re.compile("Not yet defined or implemented")
        else :
           raise 'panic panic panic in _sameLineDocComment'

        matches = re.findall(end_of_line_doc_comment_regexp, line)

        if len(matches) == 1 :
            return matches[0]
        else :
            return None


