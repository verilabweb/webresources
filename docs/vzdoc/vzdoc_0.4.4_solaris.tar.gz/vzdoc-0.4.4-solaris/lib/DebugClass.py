# ===================================================================
# Copyright (c) 2002-2005, Verilab Ltd.
# License terms as per doc/License.txt in the vzDoc distribution.
# ===================================================================
class Debug :
    """ Provides shorthand notation for other classes to include method call trace information

    An object is passed the Debug object in its constructor. Method call and return debug
    print statements are directed through the Debug object, which then controls indenting, formatting
    and enabling/disabling of debug messages on a dynamic basis. This provides both a one-liner
    way of representing method debug calls and returns in code.
    """

    enableState = 0
    indent = 0

    def out(self, string) :
        """Simple way of dumping any old string to the output"""
        if Debug.enableState :
            print string

    def methodCall(self, methodString, parameter_tuple) :
        """Prints (if enabled) indented info about a method call (name + parameters)"""
        if Debug.enableState :
            print "  "*Debug.indent + "CALL", methodString, parameter_tuple
        Debug.indent = Debug.indent + 1

    def methodReturn(self, methodString, value) :
        """Prints (if enabled) indented info about a method return (name + returned value)"""
        Debug.indent = Debug.indent - 1
        if Debug.enableState :
            print "  "*Debug.indent + "RETN", methodString, value
        return value

    def enable(self) :
        """Enables printing, returning previous enable state"""
        oldState = Debug.enableState
        Debug.enableState = 1
        return oldState

    def disable(self) :
        """Disables printing, returning previous enable state"""
        oldState = Debug.enableState
        Debug.enableState = 0
        return oldState

    def setEnableState(self, enableState) :
        """Just sets enable state - duh!, returning nothing"""
        Debug.enableState = enableState
