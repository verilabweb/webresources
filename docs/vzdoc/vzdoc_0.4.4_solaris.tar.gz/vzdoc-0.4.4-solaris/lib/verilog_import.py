#!/usr/bin/env python
# ===================================================================
# Copyright (c) 2002-2005, Verilab Ltd.
# License terms as per doc/License.txt in the vzDoc distribution.
# ===================================================================

import os,re,string,sys
import vzDoc_util

comment_regexp = re.compile(r'(/\*.*\*/|//.*)')
#unused:include_regexp = re.compile(r'^\s*`include\s+(.+)\s*$')
define_regexp  = re.compile(r'^`define\s+(.+?)\s*$')
#unused:ifdef_regexp   = re.compile(r'^\s*`ifdef\s+(.+?)\s*$')
#unused:else_regexp    = re.compile(r'^\s*`else')
#unused:endif_regexp   = re.compile(r'^\s*`endif')

def verilog_import(filename_in, defines_dir, depth):
    """
    Process imports and defines, returning a table of the current defines

    ToDo: this pass-in-a-hash, return-that-same-hash thing
    looks a bit weird.
    """
    DEBUG = 0

    print >> sys.stderr, "Loading", "  "*depth, os.path.basename(filename_in), "as verilog file - 'define constructs only in this version"

    file_in = open(filename_in)

    line_count = 0

    while 1:

       curr_line = file_in.readline()
       line_count = line_count + 1
       if not curr_line : break

       # strip comments and extra whitespace, before we get too far:
       curr_line = string.strip(re.sub(comment_regexp, '', curr_line))

       define_result = re.findall(define_regexp, curr_line)

       if define_result != [] :
           define_substitute_string = ''

           define_string_list = string.split(define_result[0])
           if len(define_string_list) == 1:
               define_match_string = define_string_list[0]
           elif len(define_string_list) == 2:
               define_match_string = define_string_list[0]
               define_substitute_string = define_string_list[1]
           else :
               vzDoc_util.warning('"%(filename_in)s", line %(line_count)d: cannot parse - %(curr_line)s' % vars())

           defines_dir["`"+define_match_string] = define_substitute_string

           if DEBUG :
               print "VERILOG DEFINE LINE !"
               print curr_line,

       line_count = line_count + 1

    file_in.close()

    return defines_dir
