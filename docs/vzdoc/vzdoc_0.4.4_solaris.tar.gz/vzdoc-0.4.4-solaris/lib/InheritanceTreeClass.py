# ===================================================================
# Copyright (c) 2002-2005, Verilab Ltd.
# License terms as per doc/License.txt in the vzDoc distribution.
# ===================================================================
import string

class ClassObject :

    def __init__(self) :
        self.methods = []
        self.fields = []
        self.events = []
        self.subClasses = []
        

class InheritanceTree :
    """ Maintains inheritance tree of classes and subClasses and their methods and fields, such that it's easy
    to print out the sections in documentation on 1) Class hierarchy, 2) Known direct sub classes,
    3) Inherited methods and 4) inherited fields. See example javadoc documentation to see how this looks"""



    def __init__(self, dbg) :
        self.dbg = dbg
        self.classDir = {}    # This will contain {className, classObj ; ....}


    def addClass(self, className) :
        """Adds a class to its list of known classes e.g. iTree.addClass("Food")"""
        if className not in self.classDir.keys() :
            self.classDir[className] = ClassObject()            
            if string.find(className, " ") >= 0:
               self.processImplicitSpecmanClassRelation(className)


    def processImplicitSpecmanClassRelation(self, subClassName) :
        """This is called if the class name has a space in it, which means it must be a Specman
        struct/unit name which represents an implicit class hierarchy/relationship without
        an 'extend' or 'like' construct ever being specified. So lets munge the name and pull
        out all the potential class relationships that are implied by the name"""
        # It is assumed that when this is called, at least one direct superclass already exists in the
        # classDir structure. So lets drop each of the determinant words in turn to generate a potential
        # supertype, and if that supertype exists, then we'll make the connection between this new
        # subtype and the already known supertype
        words = string.split(subClassName)
        for word in words[:-1] :
            trySuperClassWords = words[:]
            trySuperClassWords.remove(word)
            trySuperClass = string.join(trySuperClassWords)
            if trySuperClass in self.classDir.keys() :
                self.addSubClass(subClassName, trySuperClass)


    def addSubClass(self, subclass, superclass) :
        """Adds a subclass to its database and associates it with a superclass, which is also added
        to the database if it is not already there e.g. iTree.addSubClass("BBQFood", "Food")"""
        self.addClass(subclass)
        self.addClass(superclass)
        subclassList = self.classDir[superclass].subClasses
        subclassList.append(subclass)
        subclassList.sort()


    def addField(self, field, className) :
        """Adds a field to the list of fields owned by a class e.g. iTree.addField("weight", "Food")"""
        assert className in self.classDir.keys()
        fieldList = self.classDir[className].fields
        fieldList.append(field)


    def addEvent(self, event, className) :
        """Adds an event to the list of fields owned by a class e.g. iTree.addEvent("eaten", "Food")"""
        assert className in self.classDir.keys()
        eventList = self.classDir[className].events
        eventList.append(event)


    def addMethod(self, method, className) :
        """Adds a method to the list of methods owned by a class e.g. iTree.addMethod("eat", "Food")"""
        assert className in self.classDir.keys()
        methodList = self.classDir[className].methods
        methodList.append(method)


    def getSuperClassHierarchy(self, subClass) :
        """Returns a list of classes which is the inheritance tree of a subclass, starting with highest level class
        e.g. iTree.getSuperClassHierarchy("SquareSausage") might return [["Food"], ["BBQFood"], ["Sausage"], ["SquareSausage"]]
        Note that in order to support specman when extension, each level of the class hierarchy may contain multiple classes, so
        the structure returned is a list of lists, starting with the (single) base class and finishing with the (single)
        specified subclass)."""
        classList = [[subClass]]
        while classList[0] != [] :
            classList = self.prependSuperClasses(classList)
        return classList[1:]


    def prependSuperClasses(self, classHierarchy) :
        """classHierarchy is a list of lists. Prepend to the outermost list, a list of the direct superclasses
        of the first list of classes in the class hierarchy"""
        subClasses = classHierarchy[0]
        for subClass in subClasses :
            assert subClass in self.classDir.keys()
        
        # Gather up a list of all direct superclasses of the specified subClasses one level up
        directSuperClassList = []
        
        # Loop through all known subclasses
        for trySuperClass in self.classDir.keys() :
            trySubClassList = self.classDir[trySuperClass].subClasses    
            for trySubClass in trySubClassList :
                # If the trySubClass is one of those specified, then record its superclass
                if trySubClass in subClasses and trySuperClass not in directSuperClassList :
                    directSuperClassList.append(trySuperClass)

        directSuperClassList.sort()
        result = [directSuperClassList] + classHierarchy
        return result


    def getAllSuperClasses(self, subClass) :
        """ Return a flat version of all superclasses - no hierarchy represented"""
        classHierarchy = self.getSuperClassHierarchy(subClass)
        classList = []
        for layer in classHierarchy :
            for clazz in layer :
                classList.append(clazz)
        return classList
    

    def getDirectSubClasses(self, superclass) :
        """Returns a list of the direct (one level only) subClasses of a superclass. e.g. iTree.getDirectSubClasses("BBQFood")
        might return ["Burger", "Sausage", "Marshmallow"]"""
        assert superclass in self.classDir.keys()
        return self.classDir[superclass].subClasses


    def getAllInheritedMethods(self, subclass) :
        """Returns a tuple of a (list, directory). The list is the ordered superclass list without the specified subclass.
        In the directory each entry contains a superclass name along with a list of methods that the subclass
        inherits from the superclass. e.g iTree.getAllInheritedMethods("squareSausage") might return
        ( ["Food", "Sausage"], {"Food", ["eat", "cook"] ; "Sausage", ["prick"]}). The tuple is required since the order
        of entries in a python directory is random """
        allSuperclasses = self.getAllSuperClasses(subclass)[:-1]
        superclassesWithMethods = []
        inheritedMethodsDir = {}
        for superclass in allSuperclasses :
            if self.classDir[superclass].methods != [] :
                superclassesWithMethods.append(superclass)
                inheritedMethodsDir[superclass] = self.classDir[superclass].methods
        return (superclassesWithMethods, inheritedMethodsDir)



    def getAllInheritedFields(self, subclass) :
        """Same as getAllInheritedMethods, but gets inherited fields"""
        allSuperclasses = self.getAllSuperClasses(subclass)[:-1]
        superclassesWithFields = []
        inheritedFieldsDir = {}
        for superclass in allSuperclasses :
            if self.classDir[superclass].fields != [] :
                superclassesWithFields.append(superclass)            
                inheritedFieldsDir[superclass] = self.classDir[superclass].fields
        return (superclassesWithFields, inheritedFieldsDir)



    def getAllInheritedEvents(self, subclass) :
        """Same as getAllInheritedMethods, but gets inherited events"""
        allSuperclasses = self.getAllSuperClasses(subclass)[:-1]
        superclassesWithEvents = []
        inheritedEventsDir = {}
        for superclass in allSuperclasses :
            if self.classDir[superclass].events != [] :
                superclassesWithEvents.append(superclass)            
                inheritedEventsDir[superclass] = self.classDir[superclass].events
        return (superclassesWithEvents, inheritedEventsDir)
