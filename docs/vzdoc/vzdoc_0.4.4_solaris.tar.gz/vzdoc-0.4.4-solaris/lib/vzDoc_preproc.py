#!/usr/bin/env python
# ===================================================================
# Copyright (c) 2002-2005, Verilab Ltd.
# License terms as per doc/License.txt in the vzDoc distribution.
# ===================================================================

__version__ = "$Revision: 723 $"[11:-2]
__doc__ = """
???ToDo
"""

import os,re,stat,string,sys
import vzDoc_error
import vzDoc_util
import verilog_import

# ============================================================
_instance = None

def PreProcessor(lang=None,pathman=None,ctrl=None,sysenv=None): # NB: the singleton trick
    global _instance
    if _instance == None:
        if pathman == None or ctrl == None or sysenv == None: raise 'PreProcessor:panic' # assert
        if lang == 'specman':
            _instance = _PreProcessorSpecman(pathman,ctrl,sysenv)
        elif lang == 'vera':
            _instance = _PreProcessorVera(pathman,ctrl,sysenv)
        elif lang == 'verilog':
            _instance = _PreProcessorVerilog(pathman,ctrl,sysenv)
        elif lang == 'vhdl':
            _instance = _PreProcessorVHDL(pathman,ctrl,sysenv)
        else:
            raise 'PreProcessor:panic (lang)' # assert
    return _instance

# ............................................................
class PreProcessorALL:
    """
    Language-independent base class.
    """
    _instance = None # used above

    # ........................................................
    def __init__(self, lang, pathman, ctrl, sysenv):
        self._lang    = lang
        self._pathman = pathman
        self._ctrl    = ctrl
        self._sysenv  = sysenv

        self._worklist = {} # imported files work list
        # key is filename, value: 1 ==> started, 2 ==> done
        self._ordered_worklist = []
        # ordered_worklist is the "done" items, in the order
        # that we finish them.  This is important for specman,
        # which must hand back the filenames in that order.
        # (Other languages don't care.)
        self._consider_done = {}
        # consider_done is *similar* to the worklist, except
        # these are files we haven't *really* processed, but
        # which we want to pretend have been.

    # ........................................................
    def go(self,ifiles):
        """
        Main routine for the class.

        Returns:

        Exceptions it can throw:
        ???
        """
        if self._ctrl.verbose():
            print >> sys.stderr, 'Pre-processing',ifiles,'...'

	# ToDo: check for (a) duff ifiles, and (b) duplicate ifiles;
	# neither of these can possibly be what the user meant.

        self.preprocess_file(ifiles)

        debugging = self._ctrl.debugging(63)

        # Worklist items marked 2 (done) really are; ones
        # marked 1 (incomplete) are ones for which we couldn't
        # find source (e.g. system files).  The
        # done ones are *guaranteed* to be on _ordered_worklist
        for k in self._ordered_worklist:
            assert(self._worklist[k] == 2)
        for k in self._worklist.keys():
            if self._worklist[k] == 2:
                assert(k in self._ordered_worklist)
            elif debugging:
                print >> sys.stderr,'NB: undone worklist item:',k

        really_consider_done = []
        for k in self._consider_done.keys():
            if self._consider_done[k] == 2:
                really_consider_done.append(k)
            elif debugging:
                print >> sys.stderr,'NB: undone virtual worklist item:',k

        # Filter out the filenames that don't actually exist in the search path
        really_done_filtered = []
        for fn in self._ordered_worklist :
            if self._pathman.findInPath(fn) != None :
                really_done_filtered.append(fn)

        really_consider_done_filtered = []
        for fn in really_consider_done :
            if self._pathman.findInPath(fn) != None :
                really_consider_done_filtered.append(fn)

        return (really_done_filtered, really_consider_done_filtered)

# ............................................................
class _PreProcessorSpecman (PreProcessorALL):

    def __init__(self, pathman, ctrl, sysenv):
        PreProcessorALL.__init__(self, 'specman', pathman, ctrl, sysenv)

    # ........................................................
    def preprocess_file(self,ifiles):
        """A wrapper around the specman-specific magic"""
        import macro_defines

        defines_dir = {}
        depth = 0
        # Create macro_defines object:
        macro_defs = macro_defines.macro_defines(self._pathman)

        # _preprocess_file_int_specman returns something, but we don't use it
        for ifile in ifiles:
            self._preprocess_file_int_specman(ifile, None, defines_dir, macro_defs, depth)
            macro_defs.replace(ifile)

        #print "Imported files are : ", self.started_import_list
        #print "Defines are :"
        #pprint (defines_dir)

    # ........................................................
    def _preprocess_file_int_specman(self, ifile, importing_file, defines_dir, macro_defs, depth) :

        original_efile = self._pathman.findInPath(ifile, importing_file)
        if original_efile == None :
            return # what?

	# About a problem we saw (testcase test-e28-import-twice):

	# The file test_def.e is imported twice since the 2 imports
	# have different relative pathnames. Even though the Loading
	# message shows the same full pathname, the decision about
	# whether to import the file second time round is based on the
	# shorthand version. Testcase crashes since it gets two define
	# macro definitions and can't manage to substitute the second
	# time around.

	# In lib/vzDoc_preproc.py the method
	# _preprocess_file_int_specman is what causes the problem. For
	# specman, filename basenames must be unique, but not so in
	# Vera.  Seems that most compatible is to change the has_key()
	# check into something slightly more complex that loops
	# through the keys and check whether the file basename is
	# there.
        ifile_base    = os.path.basename(ifile)
        basename_seen = 0
        for f in self._worklist.keys():
            if os.path.basename(f) == ifile_base:
                basename_seen = 1
                break

        if basename_seen: # already in progress
            return #?defines_dir

        self._worklist[ifile] = 1 # i.e. started

        depth = depth + 1

        #original_importing_file = re.sub("(.*\.e)\..*", "\\1", os.path.basename(importing_file))
        print >> sys.stderr, "Loading", "  "*depth, original_efile

        pathman       = self._pathman
        no_line_cont  = pathman.get_no_line_cont_filename(ifile)
        code_segments = pathman.get_code_segs_filename(ifile)
        no_comments   = pathman.get_no_comments_filename(ifile)
        final_file    = pathman.get_preprocessed_filename(ifile)

        self.remove_line_continuations( original_efile, no_line_cont)
        self.extract_code_segments    ( no_line_cont, code_segments)
        self.remove_comments          ( code_segments, no_comments)

        defines_dir = self.process_imports_and_defines( no_comments,
		final_file, defines_dir, macro_defs, depth, original_efile)

        self._worklist[ifile] = 2 # done!
        self._ordered_worklist.append(ifile)

        #return defines_dir

    # ........................................................
    def remove_line_continuations(self, fin, fout) :
        """
        Remove any \ at the end of every line in a file, and tack next
        line onto it, but output equivalent newlines afterwards to
        maintain line-number correspondence.

        NB: self unused, but it is specman pp only.
        """
        file_in  = open(fin)
        file_out = open(fout, 'w')

        line_so_far = ""
        newlines = ""

        while 1 :
          curr_line = file_in.readline()
          if not curr_line : break

          index = len(curr_line)-2

          while index > 0 and (curr_line[index] == ' ' or curr_line[index] == '\t') :
              index = index - 1
          if curr_line[index] != '\\' :
              line_out = line_so_far + curr_line + newlines
              file_out.write(line_out)
              line_so_far = ""
              newlines = ""
          else :
              line_so_far = line_so_far + curr_line[0:index]
              newlines = newlines + "\n"

        file_out.write(line_so_far)
        file_out.close()
        file_in.close()

    # ........................................................
    def extract_code_segments(self, fin, fout) :
        """
        Extract all code segments from a file, replacing anything
        outside code segments with a newline such that the line
        numbers do not change

        NB: self not used, but it is specman pp only.
        """
        file_in  = open(fin)
        file_out = open(fout, 'w')

        in_code_segment = 0

        while 1 :
          line = file_in.readline()
          if not line : break

          if line[:2] == "'>" :
              in_code_segment = 0

          if in_code_segment :
              file_out.write(line)
          else :
              file_out.write("\n")

          if  line[:2] == "<'" :
              in_code_segment = 1

        if in_code_segment :
            raise ( fin + "did not finish outside a code segment")

        file_in.close()
        file_out.close()

    # ........................................................
    def remove_comments(self, fin, fout) :
        """
        Remove any comments (-- or //) from each line of a file

        NB: self not used, but this is specman pp only.
        """
        file_in  = open(fin)
        file_out = open(fout, 'w')

        #ToDo: the lexer could do this more cleanly; is that too late?

        while 1 :
            curr_line = file_in.readline()
            if not curr_line : break

            curr_line = tidy_line(curr_line)

            file_out.write(curr_line)

        file_in.close()
        file_out.close()

    # ........................................................

    #####################################################################################
    #
    #  AARGH - THIS IS A HORRIBLE CHUNK OF CODE - TO BE REPLACED BY A BEAUTIFUL SUITE
    #  OF LITTLE PREPROCESSOR AGENTS WHICH HAVE UNIT TESTS AND STUFF AND CAN BE TIED
    #  TOGETHER FAR MORE ELEGANTLY
    #
    #####################################################################################

    def process_imports_and_defines(self, filename_in, filename_out, defines_dir, macro_defs, depth, original_efile) :

        file_in  = open(filename_in)
        file_out = open(filename_out, 'w')

        verilog_import_regexp = re.compile("^\s*verilog\s+import\s+(.*);\s*$")
        import_regexp = re.compile("^\s*import\s+([^\(].*)\s*$")
        import_cyclic_regexp = re.compile("^\s*import\s+\((.*);\s*$")
        define_regexp = re.compile("^\s*`?define\s+([^<].*);\s*$")
        define_macro_regexp = re.compile("^\s*'?define\s+(<.*)$")
        ifdef_regexp = re.compile("^\s*#ifdef\s+(.+?)\s+")
        ifndef_regexp = re.compile("^\s*#ifndef\s+(.+?)\s+")
        else_regexp = re.compile("^\s*#else")
        comwhite_regexp = re.compile(",\s*")
        #unused:whitespace_only_regexp =  re.compile("^\s*$")
        #optional_leading_semicolon = re.compile("\s*;")

        line_count = 0
        ifdef_depth = 0
        waiting_for_optional_else = 0
        waiting_for_more_imports = 0
        DM_OUTSIDE = 0
        DM_GOT_MACRONAME = 1
        DM_GOT_STRING = 2
        DM_GOT_FIRST_BRACE = 3
        define_macro_state = DM_OUTSIDE
        macro = ""
        IFDEF_BLK = 0
        ELSE_BLK = 1
        current_enable =   [ 1, 1, 1, 1, 1]
        brace_count =      [ 0, 0, 0, 0, 0]
        got_first_brace =  [ 0, 0, 0, 0, 0]
        ifdef_type =     [ IFDEF_BLK, IFDEF_BLK, IFDEF_BLK, IFDEF_BLK, IFDEF_BLK]

        while 1 :

           curr_line = file_in.readline()
           line_count = line_count + 1
           if not curr_line : break

           verilog_import_result    = re.findall(verilog_import_regexp, curr_line)
           import_result            = re.findall(import_regexp, curr_line)
           import_cyclic_result     = re.findall(import_cyclic_regexp, curr_line)
           define_result            = re.findall(define_regexp, curr_line)
           define_macro_result      = re.findall(define_macro_regexp, curr_line)
           ifdef_result             = re.findall(ifdef_regexp, curr_line)
           ifndef_result            = re.findall(ifndef_regexp, curr_line)
           else_result              = re.findall(else_regexp, curr_line)
           #unused:else_match               = else_result != []
           #unused:whitespace_only          = re.findall(whitespace_only_regexp, curr_line) != []


           ###########################################
           # ifdef control
           ###########################################


           if ifdef_result != [] or ifndef_result != [] :

               # If its an #ifdef or #ifndef construct ...
               ifdef_depth = ifdef_depth + 1
               waiting_for_optional_else = 0

               # Determine whether ifdef was success of failure
               ifdef_type[ifdef_depth] = IFDEF_BLK
               success = (ifdef_result != [] and defines_dir.has_key(ifdef_result[0])) \
                  or (ifndef_result != [] and not defines_dir.has_key(ifndef_result[0]))

               # Inherit enable from parent ifdef, unless disabled
               if success :
                   current_enable[ifdef_depth] = current_enable[ifdef_depth-1]
               else :
                   current_enable[ifdef_depth] = 0


               # Start counting braces for this depth
               brace_count[ifdef_depth] = vzDoc_util.count_brace_depth(curr_line)
               got_first_brace[ifdef_depth] = brace_count[ifdef_depth] > 0
               curr_line = "\n"

           if ifdef_depth > 0 :

               # If we're in any depth of ifdef/else, then track braces to see if this block is done

               brace_count[ifdef_depth] = brace_count[ifdef_depth] + vzDoc_util.count_brace_depth(curr_line)
               if not got_first_brace[ifdef_depth] :
                   curr_line = "\n"
               got_first_brace[ifdef_depth] = got_first_brace[ifdef_depth] or brace_count[ifdef_depth] > 0
               if brace_count[ifdef_depth] == 0 and got_first_brace[ifdef_depth] :
                   if ifdef_type[ifdef_depth] == IFDEF_BLK :
                       waiting_for_optional_else = 1
                   ifdef_depth = ifdef_depth - 1
                   curr_line = "\n"

           if else_result != [] :

                if waiting_for_optional_else :
                    waiting_for_optional_else = 0
                    ifdef_depth = ifdef_depth + 1
                    current_enable[ifdef_depth] = not current_enable[ifdef_depth]
                    ifdef_type[ifdef_depth] = ELSE_BLK
                    brace_count[ifdef_depth] = vzDoc_util.count_brace_depth(curr_line)
                    curr_line = "\n"
                else :
                    raise ("Not expecting an #else at line " + str(line_count))

           enable = current_enable[ifdef_depth]


           ###########################################
           # Handle import line
           ###########################################

           if (import_result != [] or verilog_import_result != [] or waiting_for_more_imports) and enable :

               #print "**IMPORT_LINE**"

               ECODE_FILE = 0
               VERILOG_FILE = 1

               if verilog_import_result != [] :
                   import_file_type = VERILOG_FILE
               elif import_result != [] :
                   import_file_type = ECODE_FILE

               # Get comma separated string of files with no whitespace and no ';'

               if import_file_type == ECODE_FILE and not waiting_for_more_imports :
                   file_list_no_whitespace = re.sub(comwhite_regexp, ",", import_result[0])
                   #file_list_no_whitespace = string.replace(import_result[0], " ", "")
               elif import_file_type == VERILOG_FILE :
                 file_list_no_whitespace = string.replace(verilog_import_result[0], " ", "")
               else :
                 file_list_no_whitespace = string.strip(curr_line)

               #file_list_no_whitespace = string.replace(file_list_no_whitespace, "\t", "")
               file_list_no_whitespace = string.replace(file_list_no_whitespace, ";", "")
               file_list_no_whitespace = string.strip(file_list_no_whitespace)
               file_list_tmp = string.split(file_list_no_whitespace,',')
               file_list = []
               for file in file_list_tmp :
                   if file != "" :
                       file_list.append(file)

               if string.rstrip(curr_line)[-1:] == ';' :
                   waiting_for_more_imports = 0
               else :
                   waiting_for_more_imports = 1

               #print "\n", "  "* depth, "IMPORT LINE !"
               #print "  "* depth, curr_line,
               #print "  "* depth, file_list
               #print "  "* depth, waiting_for_more_imports

               for imported_file in file_list :

                   if import_file_type == ECODE_FILE :
                       imported_file = self._pathman.magicallyExpandedFilename(imported_file)
                       self._preprocess_file_int_specman(imported_file, original_efile, defines_dir, macro_defs, depth)
                   else :
                       verilog_file = self._pathman.findInPath(imported_file)
                       if verilog_file == None:
                           print >> sys.stderr, '*** WARNING: No such Verilog file in path:', verilog_file
                       else:
                           defines_dir  = verilog_import.verilog_import(verilog_file, defines_dir, depth)

               curr_line = "\n"


           ###########################################
           # Handle verilog import line
           ###########################################

           elif verilog_import_result != [] and enable :
               print "  "*depth,
               vzDoc_util.warning("'verilog import' not yet fully supported at line " + str(line_count) + " in " + filename_in)


           ###########################################
           # Handle cyclic import line
           ###########################################

           elif import_cyclic_result != [] and enable :
               print "  "*depth,
               vzDoc_util.warning("'import (cyclic)' not yet supported at line " + str(line_count) + " in " + filename_in)

           ###########################################
           # Handle define line
           ###########################################

           elif define_result != [] and enable :
               define_string_list = string.split(define_result[0])
               if len(define_string_list) == 1 :
                   define_match_string = define_string_list[0]
                   define_substitute_string = ""
               else :
                   define_match_string = define_string_list[0]
                   define_substitute_string = string.join(define_string_list[1:])

               defines_dir[define_match_string] = define_substitute_string

               #print "DEFINE LINE !"
               #print "\n", curr_line,

               curr_line = "\n"

           ###########################################
           # Handle define macro line
           ###########################################

           elif (define_macro_result != [] or define_macro_state != DM_OUTSIDE ) and enable :

               if define_macro_state == DM_OUTSIDE :
                   define_macro_state = DM_GOT_MACRONAME
                   macro = curr_line
               else :
                   macro = macro + curr_line

               no_string_line = re.sub("\".*\"", "", curr_line)

               #print curr_line,
               #print no_string_line,

               if define_macro_state == DM_GOT_MACRONAME and no_string_line != curr_line :
                   define_macro_state = DM_GOT_STRING

               if define_macro_state == DM_GOT_STRING and '{' in no_string_line :
                   define_macro_state = DM_GOT_FIRST_BRACE
                   brace_depth = 0

               if define_macro_state == DM_GOT_FIRST_BRACE :
                   brace_depth = brace_depth + vzDoc_util.count_brace_depth(curr_line)

               if define_macro_state == DM_GOT_FIRST_BRACE and brace_depth == 0 :
                   define_macro_state = DM_OUTSIDE
                   macro_defs.set(macro)

               #print define_macro_state

               curr_line = "\n"


           ###########################################
           # Substitute defines
           ###########################################

           #print curr_line, ifdef_depth, brace_count[ifdef_depth],

           if enable :

               new_line = curr_line

               # Substitute simple defines only - not macro defines
               # TBD do we want to do this - some of these may be better
               # suited to keeping the definition name in code and hyperlinking
               # to the definition.

               # NB: problems to watch out for
               # 1. substitution inside strings (undesirable)
               #     #define FOO 1
               #     f = "My name used to be FOO"
               #
               # 2. substituting for something other than a "word";
               #    e.g.
               #     #define FOO 42
               #     #define FOO_BAR "Erra dug"
               #    and then changing
               #     f = FOO_BAR
               #    into
               #     f = 42_BAR
               #    (We avoid this by matching on word boundaries.)

               for define in defines_dir.keys() :
                   if defines_dir[define] != "" :
                       new_line = re.sub("\\b"+define+"\\b", defines_dir[define], new_line)
                       #print >> sys.stderr, 'substituting:',define,'in:', defines_dir[define],'giving:',new_line

               #if new_line != curr_line :
               #    print >> sys.stderr, "\nLINE CHANGED\n", curr_line, new_line

               file_out.write(new_line)

           else :
               file_out.write("\n")

           line_count = line_count + 1


           #######################################################
           # End of process_imports_and_defines() line while loop
           #######################################################

        file_out.close()
        file_in.close()

        return defines_dir

# ............................................................
def tidy_line(line):
    """Removes the // or -- comments from a single line.
       But not out of string literals...
    """
    i = 0
    in_string = 0
    #print >>sys.stderr, 'line=',line
    while i < len(line):
        #print 'i=',i,'len-2=',len(line) - 2,'in_string=',in_string,'line=',line,
        if line[i] == "\\":
            try:
                if line[i+1] == '"' or line[i+1] == "\\":
                    i = i+2
                    continue
            except IndexError: pass

        elif line[i] == '"' :
            in_string = not in_string

        elif not in_string:
            try:
                if line[i:i+2] == "//" or line[i:i+2] == "--":
                    line = line[0:i] + "\n"
                    break
            except IndexError: pass

        i = i + 1

    assert(not in_string)  
    return line

def tidy_line_tests():
    print tidy_line("EVC_TRACE_METHOD -prefix=\"\"\n"),
    print tidy_line("foo \\\n"),
    print tidy_line("foo \\//\n"),
    print tidy_line("foo \\--\n"),
    print tidy_line("foo \\/\n"),
    print tidy_line("foo \\-\n"),
    print tidy_line("foo /\n"),

# ............................................................
class _PreProcessorVera (PreProcessorALL):

    def __init__(self, pathman, ctrl, sysenv):
        PreProcessorALL.__init__(self,'vera', pathman, ctrl, sysenv)

    # ........................................................
    def preprocess_file(self, ifiles):
	#print >> sys.stderr, 'vera pp:',ifiles

        pathman = self._pathman

        # seed the work list with the ifiles:
        for ifile in ifiles[1:]:
            orig_ifile = pathman.findInPath(ifile)
            assert(not self._worklist.has_key(orig_ifile))
            self._worklist[orig_ifile] = 1 # queue it up

	ifile1 = pathman.findInPath(ifiles[0])
	self.preprocess_file_rec(ifile1)

    def preprocess_file_rec(self, ifile):
        if self._worklist.has_key(ifile) and self._worklist[ifile] == 2: # already done
            return # what?

        debugging = self._ctrl.debugging(63)

        pathman = self._pathman
        original_filename = pathman.findInPath(ifile)

        if original_filename == None: # ToDo: this is horrible
            if debugging:
                print >> sys.stderr, 'vera pp - PSEUDO DONE!: %s'%(ifile)
            self._worklist[ifile] = 2 # done!
            self._ordered_worklist.append(ifile)
            return

        final_filename    = pathman.get_preprocessed_filename(ifile)
        error_log         = pathman.get_preprocessed_errors_filename(ifile)

        if os.environ.has_key('VZDOC_VERA_PP'):
            vera_pp = os.environ['VZDOC_VERA_PP']
        else:
            vera_pp = self._sysenv.findPgm('vera') + ' -pp'

        args = ['>'+final_filename, '2>'+error_log]

        (dummy, veradirs) = self._ctrl.langPath()
        for dir in veradirs:
	    args.append('-I'+dir)

	arglist = string.join(args, ' ')
        status  = vzDoc_util.runScript(self._ctrl,
"""
/bin/rm -f /tmp/vzdoc$$__PP.vr
echo '# 1 "%(original_filename)s"' > /tmp/vzdoc$$__PP.vr ;
sed -e 's,// vzdoc translate ,=-=vzdoc-trans=-=,g' < %(original_filename)s >> /tmp/vzdoc$$__PP.vr ;
%(vera_pp)s /tmp/vzdoc$$__PP.vr %(arglist)s
stat=$?
/bin/rm -f /tmp/vzdoc$$__PP.vr
exit $stat
""" % vars() )

        if status != None or os.stat(error_log)[stat.ST_SIZE] != 0 :
            errors = vzDoc_util.read_file_into_string(error_log)
            vzDoc_util.error_and_exit("Preprocessor errors :\n " + errors)

        if debugging:
	    print >> sys.stderr, 'vera pp - DONE!: %s (%s)'%(ifile,original_filename)
        self._worklist[ifile] = 2 # done!
        self._ordered_worklist.append(ifile)

        # Notably: if we see a .vrh file, we preprocess the
        # corresponding .vr file -- **IF** that .vr file is
        # not in the imported_here list as well (or already
        # done).  Moreover, the .vr files in the list count
        # as *already done*.

        imported_here = self.getImportedFileList(final_filename)
        #print >> sys.stderr,'imported_here=',`imported_here`

        # So: first mark the already done ones:
        for ifil in imported_here:
            if ifil[-7:] == '__PP.vr': continue # hack me gently...

            if self._worklist.has_key(ifil):      continue
            if self._consider_done.has_key(ifil): continue # virtually done...

            if ifil[-3:] == '.vr' or ifil[-3:] == '_vr':
                if debugging:
                    print >> sys.stderr, '.vr - VIRTUALLY DONE!: %s'%ifil
                self._consider_done[ifil] = 2 # (Pretend) DONE!

            elif ifil[-4:] == '.vri':
                if debugging:
                    print >> sys.stderr, '.vri - VIRTUALLY DONE!: %s'%ifil
                self._consider_done[ifil] = 2 # (Pretend) DONE!

            elif ifil[-2:] == '.v': # stay out of the Verilog game... 
                if debugging:
                    print >> sys.stderr, '.v - VIRTUALLY DONE!: %s'%ifil
                self._consider_done[ifil] = 2 # (Pretend) DONE!

            # ToDo: this next bit is here so we get .vrh.html files
            # out of the htmlizer, but DaveF, uttering a side note,
            # thinks they may never be referenced....
            elif ifil[-4:] == '.vrh':
                try:
                    where = self._pathman.findInPath(ifil)
                    if debugging:
                        print >> sys.stderr, '.vrh - VIRTUALLY DONE!: %s (%s)'%(ifil,where)
                    self._consider_done[ifil] = 2 # virtually DONE!
                except vzDoc_error.VzDocNotInPath:
                    if debugging:
                        print >> sys.stderr, '.vrh - NOT FOUND DONE!: %s'%ifil
                    self._consider_done[ifil] = 1 # virtually virtually DONE!

            else:
                print >> sys.stderr, "ifil = ", ifil
                raise 'panic after getImportedFileList'

	# Now deal with those possibly-stray .vrh files:
        for ifil in imported_here:
            if ifil[-4:] != '.vrh': continue

            # consider this one magical:
            if ifil == 'vera_defines.vrh': continue

            # NB: ifil[:-1] is the .vr equiv
            ifil = ifil[:-1]

            if self._worklist.has_key(ifil):      continue
            if self._consider_done.has_key(ifil): continue # virtually done...

            if debugging:
                print >> sys.stderr, 'adding to worklist Q:',ifil
            self._worklist[ifil] = 1 # queue it up if not done yet

        # Go through our worklist, and do the queued stuff;
        for file in self._worklist.keys() :
	    if self._worklist[file] == 2: continue # old news...

            try:
                where = self._pathman.findInPath(file)
                #print >> sys.stderr, 'vera pp - recursing:',file
                self.preprocess_file_rec(file)
            except vzDoc_error.VzDocNotInPath:
                pass # OK...  # NB: system things won't be

    # ........................................................
    def getImportedFileList(self, filename) :
	"""
        Given full path of a preprocessed file, derives a list
        of all files (well, really, their basenames)
	referenced during the preprocessing

        We used to have code here that only snagged files
        in VERA_PATH, which we had suitably mangled at startup.
	This was so we could magically filter out "unwanted"
        system files.  Removed, in the hope that the need has
        gone away.
	"""
        wholefile = vzDoc_util.read_file_into_string(filename)
        #print >> sys.stderr, '<<',wholefile,'>>'

        result = {} # use a hash to avoid duplicates

        for fn in re.findall(r'# [0-9]+ "(.*?)"', wholefile):
            if fn in ['<built-in>', '<command line>', '<stdin>']: continue # cpp things...
            assert(fn != '')
            result[os.path.basename(fn)] = 1

        #print >> sys.stderr, 'importedFiles <%s>' % string.join(result.keys(),'> <')
        return result.keys()

# ............................................................
class _PreProcessorVerilog (PreProcessorALL):

    def __init__(self, pathman, ctrl, sysenv):
        PreProcessorALL.__init__(self, 'verilog', pathman, ctrl, sysenv)

# ............................................................
class _PreProcessorVHDL (PreProcessorALL):

    def __init__(self, pathman, ctrl, sysenv):
        PreProcessorALL.__init__(self, 'vhdl', pathman, ctrl, sysenv)

    # ........................................................
    def preprocess_file(self,ifiles):
        """A not-yet-written VHDL-specific preprocessor"""

        pathman = self._pathman

        # seed the work list with the ifiles:
        for ifile in ifiles[1:]:
            orig_ifile = pathman.findInPath(ifile)
            assert(not self._worklist.has_key(orig_ifile))
            self._worklist[orig_ifile] = 1 # queue it up

	ifile1 = pathman.findInPath(ifiles[0])
	self.preprocess_file_rec(ifile1)

    def preprocess_file_rec(self,ifile):
        print >> sys.stderr, 'NB: No real VHDL Preprocessor Written yet - ifile is',ifile,'...'

        if self._worklist.has_key(ifile) and self._worklist[ifile] == 2: # already done
            return

        debugging = self._ctrl.debugging(63)

        pathman = self._pathman
        original_filename = pathman.findInPath(ifile)
        final_filename    = pathman.get_preprocessed_filename(ifile)

        import shutil
        shutil.copyfile(original_filename,final_filename)

        if debugging:
	    print >> sys.stderr, 'vhdl pp - DONE!: %s (%s)'%(ifile,original_filename)
        self._worklist[ifile] = 2 # done!
        self._ordered_worklist.append(ifile)

        # Go through our worklist, and do the queued stuff;
        for file in self._worklist.keys() :
	    if self._worklist[file] == 2: continue # old news...

            try:
                where = self._pathman.findInPath(file)
                #print >> sys.stderr, 'vhdl pp - recursing:',file
                self.preprocess_file_rec(where)
            except vzDoc_error.VzDocNotInPath:
                pass # OK...  # NB: system things won't be

# ============================================================
def test():
    tidy_line_tests()
    raise 'vzDoc_preproc: test'

# ============================================================
if __name__ == '__main__':
    test()
