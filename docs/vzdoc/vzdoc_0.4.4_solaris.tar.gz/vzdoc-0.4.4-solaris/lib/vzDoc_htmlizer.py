#!/usr/bin/env python
# ===================================================================
# Copyright (c) 2002-2005, Verilab Ltd.
# License terms as per doc/License.txt in the vzDoc distribution.
# ===================================================================

__version__ = "$Revision: 723 $"[11:-2]
__doc__ = """
???ToDo
"""

import sys, string
import vzDoc_util

# ============================================================
def Htmlizer(pathman=None,ctrl=None): # NB: the singleton trick
    if _Htmlizer._instance == None:
        if pathman == None or ctrl == None: raise 'Htmlizer:panic' # assert
	_Htmlizer._instance = _Htmlizer(pathman,ctrl)
    return _Htmlizer._instance

class _Htmlizer:
    """
    ???ToDo
    """
    _instance = None # used above

    # ........................................................
    def __init__(self, pathman, ctrl):
        self._pathman = pathman
        self._ctrl    = ctrl

    # ........................................................
    def go(self,file):
        """
        Main routine for the class.
        """
        if self._ctrl.verbose():
            print >> sys.stderr, 'HTMLizing',file,'...'
        pathman = self._pathman
        self.convert_to_html(file, pathman.findInPath(file), pathman.get_code_html_full_path(file))

    # ........................................................

    def convert_to_html(self, fin_display, fin, fout) :
        """
        Convert the file to HTML such that all lines have targets
        associated with them

        Returns: nothing

        Exceptions: VzDocBadClose, if file writing fails nastily
        """
        #print "convert_to_html(fin_display = %s, fin = %s, fout = %s)" % (fin_display, fin,fout)

        file_in  = open(fin)
        file_out = open(fout, 'w')

        doctype = vzDoc_util.htmlDoctype()
	metas   = vzDoc_util.metaTags()
        file_out.write("""\
%(doctype)s
<HTML>
<HEAD>
%(metas)s
<TITLE>
%(fin)s source
</TITLE>
<BODY>
<PRE>
""" % vars())
# ToDo: BUG -- %(fin)s would be prettier as %(fin_display)s

        line_number = 0

        while 1 :
            curr_line = file_in.readline()
            if not curr_line : break

            # escape HTML meta-chars: & < >  (ToDo: maybe more?)
            curr_line = string.replace(curr_line, "&", "&amp;")
            curr_line = string.replace(curr_line, "<", "&lt;")
            curr_line = string.replace(curr_line, ">", "&gt;")

            if len(curr_line) > 0:
                if curr_line[-1] == '\n':
                    before = curr_line[:-1]
                    if before == '': before = '&nbsp;';
                    after  = '\n'
		else: # there is a line, but not a newline on the end
		    before = curr_line
		    after  = ''
	    else: # hmmm... nothing there... (unlikely, maybe impossible?)
		    before = '&nbsp;' # so we have *something* inside <a></a>
		    after  = ''

            file_out.write('<a name="%d">%s</a>%s' % (line_number, before, after))
            line_number = line_number + 1

        file_out.write("</PRE></BODY></HTML>\n")
        file_out.close()
        file_in.close()

# ============================================================
