#!/usr/bin/env python
# ===================================================================
# Copyright (c) 2002-2005, Verilab Ltd.
# License terms as per doc/License.txt in the vzDoc distribution.
# ===================================================================

#############################################################################
# Import various packages
#############################################################################

import os, re, string, sys

import vzDoc_error,vzDoc_util
from pprint                   import pprint
from DefineMacroReplacerClass import DefineMacroReplacer
from DebugClass               import Debug


#########################################################################
#
# This class manages macro define substitution
#
#########################################################################

class macro_defines :

    def __init__(self, pathman):
        self._pathman = pathman

        self.match_regexp_dir = {}
        self.replacement_string_dir = {}
        self.tokens_dir = {}
        self.quick_match_word_list = []
        self.optional_match_regexp = re.compile("(\[.*?\])|(<.*?>)")
        self.name_list = []
        self.name_hash = {} # same but in hash form


    #####################################################################
    # Set up a new macro definition, given the full define macro
    #####################################################################

    def set(self, macro) :

        #print "Macro = '" + macro + "'"

        macro_name = re.findall("<.*?>",macro)[0]
        if self.name_hash.has_key(macro_name):
            sys.stderr.write('macro already defined? - %s\n'%macro_name)
        else:
            self.name_list.append(macro_name)
            self.name_hash[macro_name] = 1

        # Split macro into basic match and replacement - non regexp versions at this stage

        match_list = re.findall("\"(.*?)\"", macro)
        if match_list == [] :
            vzDoc_util.warning("Could not parse macro define : " + macro)
        original_match_string = match_list[0]

        no_match_string = re.sub(original_match_string, "", macro)
        first_brace_index = string.find(no_match_string, "{")
        last_brace_index = string.rfind(no_match_string, "}")
        original_replacement_string = no_match_string[first_brace_index + 1 : last_brace_index]


        # Now turn the match string into a regexp and create a list of its match tokens

        match_regexp_string = re.sub("<.*?>", R"(\S*)",  original_match_string) # Replace tokens by regexp equivalents
        match_regexp_string = re.sub(" ", R"\s+", match_regexp_string)          # Replace spaces by any amount of whitespace
        match_regexp_string = match_regexp_string + "\s*;?"                     # Optional semicolon at end
        match_regexp = re.compile(match_regexp_string)                          # Make compiled regexp object

        match_token_list = re.findall("<.*?>", original_match_string)


        # Get a single keyword from the match string to allow fast approximate match

        quick_match_word = ""
        mandatory_stuff = re.sub(self.optional_match_regexp, "", original_match_string)
        original_match_words = string.split(mandatory_stuff)
        for word in original_match_words :
            if len(word) > len(quick_match_word) :
                quick_match_word = word

        if match_list == [] :
            vzDoc_util.warning("Could not parse macro define : " + macro)
        # Debugging prints

        #print "\n\n**DEFINE_MACRO DEFINITION**"
        #print "Basic match string = '" + original_match_string + "'"
        #print "Regexp match string = '" + match_regexp_string + "'"
        #print "Mandatory stuff = '" + mandatory_stuff + "'"
        #print "Quick_match_word = '" + quick_match_word + "'"
        #print "Parameters =", match_token_list
        #print "Basic replacement string = '" + original_replacement_string + "'"


        # Store all relevant stuff into directories

        self.match_regexp_dir[original_match_string] = match_regexp
        self.replacement_string_dir[original_match_string] = original_replacement_string
        self.tokens_dir[original_match_string] = match_token_list
        self.quick_match_word_list.append(quick_match_word)



    def replace(self, ifile) :

        if self.name_list == [] :
            return

        log = self.get_specman_log(ifile)
        replacement_map = self.get_replacement_map(log)
#        print >>sys.stderr, 'replacement_map=',`replacement_map`
#        pprint (replacement_map)
        defineMacroReplacer = DefineMacroReplacer(Debug())
        for filename in replacement_map.keys() :
            preprocessed_filename = self._pathman.get_preprocessed_filename(filename)
            file = vzDoc_util.read_file_into_string(preprocessed_filename)
            replaced_file = defineMacroReplacer.replace(file, replacement_map[filename])
            os.rename(preprocessed_filename, preprocessed_filename + "_undef")
            pp_file = open(preprocessed_filename, 'w')
            pp_file.write(replaced_file)
            pp_file.close()

    def get_specman_log(self, ifile) :

#        print >>sys.stderr, self.name_list
        system_call = "specman -c \"" + \
                      "trace reparse ; " + \
                      "load " + self._pathman.findInPath(ifile) + \
                      "\""
#        print >>sys.stderr, system_call
        specman_job = os.popen(system_call)
        log = specman_job.read()
#        print >>sys.stderr, 'log=',log
        sstatus = specman_job.close()
        # ToDo - this BadClose Exception does catch some very valid stuff and must
        # be re-enabled, but for the moment, just to match up merged with last_split
        # we'll comment it out so that stuff runs.
        #
        # partain 2002.10: this is all a hack, but it's better than
        # not checking
        if sstatus != None:
            if string.find(log,'Cannot acquire license to load an encrypted file') >= 0:
                # we can live with that one
                pass
            elif string.find(log,'Couldn\'t acquire license') >= 0:
                raise vzDoc_error.VzDocNoLicense,'specman'
            else:
                print >>sys.stderr, 'sstatus=',sstatus
                raise vzDoc_error.VzDocBadClose,system_call
        os.remove("specman.elog")
        #print >>sys.stderr, log # Uncomment this to show the logfile that specman spat out
        return log


    def get_replacement_map(self, log) :
        """ Map is a directory with lists of tuples, e.g. :
        {
          "filename1" : [("match1", "replace1"), ("match2", "replace2"), ...],
          "filename2" : [("matchN", "replaceN")]
        }

	The lists are ordered such that:
           match1 does not appear in match2, replace2, match3, replace3, ...
	"""

        load_regexp = re.compile("^(Loading\s+.*?\s+)", re.M)
        segments = re.split(load_regexp, log)

#        pprint(segments)

        replacement_map = {}
        current_file = None
        for segment in segments :
            if segment[:7] == "Loading" :
                current_file = string.split(segment)[1]
            else :
                trace_list = self.order_traces(self.get_substitution_traces(segment))
                if current_file != None and trace_list != []:
                   replacement_map[current_file] = trace_list

        return replacement_map

    def get_substitution_traces(self, segment) :
        """ For this segment, find all traces that we're interested in"""
        trace_list = []
	
#OLD	# NOTE from DaveF on why the .reverse() that follows:
# 	#
# 	# For each file, it goes through the known define macro list,
# 	# looking at the specman run output log to figure out a
#         # list of what to replace and with what. The specman log
#         # doesn't show the complete (i.e. innermost+outermost macro
#         # done all at once) replacement for each thing but shows the
#         # first outermost replacement then the innermost replacement
#         # as separate replacements. Unfortunately, I go through the
#         # list of known define macros from first to last
#         # (i.e. innermost replacement to outermost replacement). I
#         # think the fix is just to go through the self.name_list
#         # backwards, thus ensuring that we do all replacements outermost
#         # first.
#         self.name_list.reverse()

        for macro_name in self.name_list:
            full_sub_regexp = re.compile("D> " + macro_name + " '(.*?)'\nD> reparsed as: '(.*?)'\n",re.DOTALL)
            subs = re.findall(full_sub_regexp, segment)
            trace_list = trace_list + subs

        #pprint (trace_list)
        return trace_list

    def order_traces(self, trace_list):
        """See documentation above"""
        res     = []
        pending = trace_list
#        print >> sys.stderr, 'tracelist=', trace_list
        n = 0
        while len(pending) > 0 and n < 512:
#            print >> sys.stderr, 'pending is',`pending`
            (match1,replace1) = pending[0]
            occurs = 0
            for (m,r) in pending[1:]:
                if string.find(r,match1) >= 0:
                    occurs = 1
                    break
                elif m == match1:
                    pass
                elif string.find(m, match1) > 0: #ToDo: why not >= 0? (partain 2003.10)
                    occurs = 1
                    break

            pending = pending[1:]
            if occurs:
                #print >> sys.stderr, 'defer',match1
                pending.append((match1,replace1))
                #print >> sys.stderr, 'pending now', `pending`
            else:
 #               print >> sys.stderr, 'accept',match1
                res.append((match1, replace1))
            n = n+1

        if n >= 512:
            print >> sys.stderr,'macro replace ran amok!\n'
            sys.exit(1)
#        print >> sys.stderr, 'result=', `res`
        return res
