#!/usr/bin/env python
# ===================================================================
# Copyright (c) 2002-2005, Verilab Ltd.
# License terms as per doc/License.txt in the vzDoc distribution.
# ===================================================================

__version__ = "$Revision: 723 $"[11:-2]
__doc__ = """
???ToDo
"""

import os,string,sys,re
import vzDoc_error
import vzDoc_util

# ============================================================
def Parser(lang=None,pathman=None,ctrl=None,sysenv=None): # NB: the singleton trick
    if _Parser._instance == None:
        if lang == None or pathman == None or ctrl == None or sysenv == None: raise 'Parser:panic' # assert
	_Parser._instance = _Parser(lang,pathman,ctrl,sysenv)
    return _Parser._instance

class _Parser:
    """
    ???ToDo
    """
    _instance = None # used above

    # ........................................................
    def __init__(self, lang, pathman, ctrl, sysenv):
        self._lang    = lang
        self._pathman = pathman
        self._ctrl    = ctrl
        self._sysenv  = sysenv

    # ........................................................
    def go(self,fn):
        """
        Main routine for the class.

        Given a pre-processor-output file, parse it, leaving
        dribblings as appropriate.
        """
        if self._ctrl.verbose():
            print >> sys.stderr, 'Parsing',fn,'...'

        pathman = self._pathman

        pp_fn  = pathman.get_preprocessed_filename(fn)

        if not os.path.exists(pp_fn):
            # we used to be happy with this, but ??? ToDo
            raise vzDoc_error.VzDocNoSuchPath,pp_fn

        parsed_fn = pathman.get_parsed_filename(fn)
        stderr_fn = pathman.get_parsing_debug_filename(fn)

        (parser,magic_args) = self._sysenv.findParser(self._lang)
        args = magic_args + [
		 ' <'+pp_fn
               , '1>'+parsed_fn
               , '2>'+stderr_fn
	       ]

        status = vzDoc_util.runPgm(self._ctrl, parser, args)

        parsed_hacked_fn = pathman.get_parsed_filename_HACKED(fn)
        if parsed_hacked_fn != parsed_fn :
            status = 1
            parsed_fn = parsed_hacked_fn

        if status != None \
	or (not os.path.exists(parsed_fn)) :
            if os.path.exists(parsed_fn):
                try:
                    parser_error(stderr_fn,fn)
                except vzDoc_error.VzDocSyntaxError,msg:
                    sys.stderr.write(msg)
                    sys.exit(1)
                except vzDoc_error.VzDocGrammarAmbiguity,msg:
                    sys.stderr.write(msg)
                    sys.exit(1)
            else:
                vzDoc_util.error_and_exit( "in parser execution (rather than a syntax error in code)")

# ============================================================
def parser_error(parser_output_file, original_filename) :

  parser_out = open(parser_output_file)

  lines = []
  while 1 :
    line = parser_out.readline()
    if not line :
      break
    lines.append(line)
  parser_out.close()

  nlines = len(lines)

  if nlines == 0 : return # surely?

  if nlines > 0 and string.find(lines[-1], ": syntax error") >= 0 :
     raise vzDoc_error.VzDocSyntaxError,('"%s", %s: %s\n' % (original_filename, string.rstrip(lines[-1]), lines[-2]))

  if nlines > 0 and string.find(lines[-1], "parsing error") >= 0 :
     raise vzDoc_error.VzDocSyntaxError,('"%s": %s\n' % (original_filename, string.rstrip(lines[-1])))

  if nlines > 0 and string.find(lines[-1], ": source text uncovers unhandled grammar ambiguity") >= 0 :
     grammar_debug_regexp = re.compile( "(GRAMMAR DEBUG INFORMATION.*END OF GRAMMAR DEBUG INFORMATION)", re.S)
     grammar_debug_msg = re.findall(grammar_debug_regexp, string.join(lines,""))
     raise vzDoc_error.VzDocGrammarAmbiguity,("""\"%s\", line %s: grammar ambiguity\n%s\n%s\n""" \
                                              % (original_filename,string.rstrip(lines[-1]),\
                                                 grammar_debug_msg[0], vzDoc_util.get_support_msg()))

  raise ("\n" + string.join(lines,'') + "\n" + vzDoc_util.get_support_msg())

# ============================================================
