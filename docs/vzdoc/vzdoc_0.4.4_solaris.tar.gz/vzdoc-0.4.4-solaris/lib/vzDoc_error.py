#! /usr/bin/env python
# ===================================================================
# Copyright (c) 2002-2005, Verilab Ltd.
# License terms as per doc/License.txt in the vzDoc distribution.
# ===================================================================
__version__ = "$Revision: 723 $"[11:-2]
__doc__ = """
vzDoc exceptions module
"""

# ============================================================
VzDocGrammarAmbiguity = 'Grammar ambiguity'
VzDocJunkSymlink      = 'Symlink to nowhere'
VzDocNoEnvVarMatch    = 'No environment variable to use in substitution'
VzDocNoFilenameInNode = 'No filename in DOM node'
VzDocNoSuchPath       = 'No such path'
VzDocNotImplemented   = 'Not implemented yet'
VzDocNotInPath        = 'Not found in the path'
VzDocParserNotFound   = 'Language-specific parser not found'
VzDocSyntaxError      = 'Syntax error'
VzDocBadClose	      = 'Close failed'
VzDocNoLicense	      = 'No license available'

# ============================================================

# ============================================================
if __name__ == '__main__':
    test()
