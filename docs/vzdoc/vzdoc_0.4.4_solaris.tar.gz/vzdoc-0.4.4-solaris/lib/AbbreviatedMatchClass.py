# ===================================================================
# Copyright (c) 2002-2005, Verilab Ltd.
# License terms as per doc/License.txt in the vzDoc distribution.
# ===================================================================
import re
import string

class AbbreviatedMatch :

    def __init__(self, dbg, matchString) :
        """Initialises an abbreviated type of match string - e.g. {...}"""
        assert matchString in ["{...}","[...]","(...)","\"...\""]
        self.dbg = dbg
        self.match = matchString
        self.stringMatch   = matchString == "\"...\""
        self.bracesMatch   = matchString == "{...}"
        self.bracketsMatch = matchString == "[...]"
        self.parensMatch   = matchString == "(...)"

    def getType(self) :
        return "AbbreviatedMatch"

    def findFirst(self, file) :
        """Find the first incidence of a **MATCHED** pair of the particular type, returning
        a start and end position tuple for the match - such that doing a slice using the start
        and end delivers exactly the match. Pattern is guaranteed to exist somewhere in file"""

        methodString = "AbbreviatedMatch.findFirst(file)"
        self.dbg.methodCall(methodString, "'" + file + "'")

        tryStart = 0
        found = 0
        while tryStart < len(file) :
            start = self.findChar(file, self.match[0], tryStart)
            length = self.eat(file[start:])
            if length == None :
                tryStart = start + 1
                continue
            else :
                self.dbg.methodReturn(methodString, str((start, start + length)) )
                return (start, start + length)

        assert 1, "Couldn't find '" + self.match + "' in file"


    def eat(self, file) :
        """Returns the length of the match if matchString is the next in the file, else return None"""

        methodString = "AbbreviatedMatch.eat(file)"
        self.dbg.methodCall(methodString, "'" + file + "'")

        originalLength = len(file)
        file = string.lstrip(file)

        if file[0] != self.match[0] :
            self.dbg.methodReturn(methodString, str(None) )
            return None

        file = file[1:]                 # Chop off leading character
        numStrippedChars = originalLength - len(file)
        prevChar = self.match[0]
        inString = self.stringMatch
        braceDepth   = 1
        bracketDepth = 1
        parenDepth   = 1
        index = 0

        for char in file :

            if prevChar + char == "\\\"" :
                pass
            elif char == '"' :
                inString = not inString
            elif char == '{' and not inString :
                braceDepth = braceDepth + 1
            elif char == '}' and not inString :
                braceDepth = braceDepth - 1
            elif char == '[' and not inString :
                bracketDepth = bracketDepth + 1
            elif char == ']' and not inString :
                bracketDepth = bracketDepth - 1
            elif char == '(' and not inString :
                parenDepth = parenDepth + 1
            elif char == ')' and not inString :
                parenDepth = parenDepth - 1

            if self.bracesMatch   and braceDepth == 0   or \
               self.bracketsMatch and bracketDepth == 0 or \
               self.parensMatch   and parenDepth == 0   or \
               self.stringMatch   and not inString :
                 length = index + numStrippedChars + 1
                 self.dbg.methodReturn(methodString, str(length) )
                 return length

            prevChar = char
            index = index + 1

        self.dbg.methodReturn(methodString, str(None) )
        return None


    def findChar(self, file, matchChar, minIndex) :
        """Find the first instance of char in the file that's not inside a string
        - version of string.find(..) that doesn't look inside strings. Assume that
        we start outside a string"""

        prevChar = ""
        index = 0
        inString = 0
        for char in file :
            if prevChar + char == "\\\"" :
                pass
            elif not inString and index >= minIndex and char == matchChar :
                return index
            elif char == '"' :
                inString = not inString
            index = index + 1
            prevChar = char

        return None

