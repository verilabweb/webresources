
# __init__ for xml.sax.drivers
