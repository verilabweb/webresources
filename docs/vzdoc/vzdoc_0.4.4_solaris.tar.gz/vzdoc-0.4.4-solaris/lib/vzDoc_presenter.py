#!/usr/bin/env python
# ===================================================================
# Copyright (c) 2002-2005, Verilab Ltd.
# License terms as per doc/License.txt in the vzDoc distribution.
# ===================================================================

__version__ = "$Revision: 723 $"[11:-2]
__doc__ = """
???ToDo
"""

import os,re,string,sys,time

import vzDoc_dom
import vzDoc_util
import vzDoc_doc_comment_manager

# ============================================================
def Presenter(lang=None,pathman=None,ctrl=None, inheritance_tree=None): # NB: the singleton trick
    if _Presenter._instance == None:
        if lang == None or pathman == None or ctrl == None or inheritance_tree == None: raise 'Presenter:panic' # assert
	_Presenter._instance = _Presenter(lang, pathman, ctrl, inheritance_tree)
    return _Presenter._instance

class _Presenter:
    """
    ???ToDo
    """
    _instance = None # used above

    # ........................................................
    def __init__(self, lang, pathman, ctrl, inheritance_tree):
        self._lang    = lang
        self._pathman = pathman
        self._ctrl    = ctrl
        self._defined_things = [] # keep pychecker happy
        self._inheritance_tree = inheritance_tree
        self._doc_comment_manager = vzDoc_doc_comment_manager.DocCommentManager(lang, pathman, ctrl)

    # ........................................................
    def go(self,ifiles,defined_things,defined_things_to_display,uses):
        """
        Main routine for the class.
        """
        if self._ctrl.verbose():
            print >> sys.stderr, 'Presenting',ifiles

        self._defined_things = defined_things # save away for later use

        # Find the shortest name ending with
        # 'env' - to be used as the initial struct page to show.
        # (Quelle hack!)
        initial_name = None
        for usename in uses.keys():
            if usename[-3:] == "env":
                if initial_name == None or len(usename) < len(initial_name):
                    initial_name = usename

	if initial_name == None : # match the one that will be in the top-left corner
	    initial_name = defined_things_to_display[0]

        # Create main top level index HTML page - first, to help debug
        self.create_main_index(ifiles, initial_name)

        # Create top level HTML frame which lists all defined things:
        self.create_all_defs_frame(defined_things_to_display)

	# Create vzDoc.css (default):
        self.create_vzdoc_css()

        # Create HTML frames for each individual thing. Give the
        # creator the name of the thing (name of HTML page), the list
        # of DOM nodes that are associated with that thing, and
        # the complete list of things so we know when to hyperlink to
        # other structs in the HTML
        for usename in uses.keys():
            self.create_use_html(usename, uses[usename])

    # ........................................................
    def create_main_index(self, ifiles, initial_name):
        """
        Create main index HTML page, containing the 2 frames of the
	struct list and an initial struct frame
        """
        fn   = self._pathman.get_main_index_html()
        html = open(fn, 'w')

	frame_name     = self.get_frame_name()
        frame_name_all = self.get_frame_name_all()

        frame_html_all = self._pathman.get_all_frame_html()
	tidied_name = string.replace(initial_name, " ", "__")
        doctype = vzDoc_util.htmlDoctype(does_frames=1)
	metas   = vzDoc_util.metaTags()

        if len(ifiles) == 1:
            title = ifiles[0] + ' documentation'
	else:
            title = 'documentation for: ' + string.join(ifiles,', ')

        html.write("""\
%(doctype)s
<HTML>
<HEAD>
%(metas)s
<TITLE>
%(title)s
</TITLE>
</HEAD>
<FRAMESET cols="25%%,75%%">
<FRAME src="%(frame_html_all)s" name="%(frame_name_all)s">
<FRAME src="%(tidied_name)s.html" name="%(frame_name)sFrame">
<NOFRAMES>
<BODY>
<H1>Feeble non-frames alternative</H1>

<A HREF="%(frame_html_all)s">All defined entities</A>
</BODY>
</NOFRAMES>
</FRAMESET>
</HTML>
"""  % vars())
        html.close()

    # ........................................................
    def create_vzdoc_css(self):
        """
        Create default CSS file
        """
        fn   = self._pathman.get_vzdoc_css()
        css = open(fn, 'w')

	# use the alt file if requested; otherwise, generate the default one
        alt_css = self._ctrl.altCssFile()
        if alt_css != None:
            alt = open(alt_css)
            while 1:
                l = alt.readline()
                if not l: break
                css.write(l)
            alt.close()

	else: # the default, please
	    # initially contributed by Mahesh Asolkar at Synopsys (2004.07, partain)
	    css.write("""\
a
{ color                 : blue
; text-decoration       : none
}

a:hover
{ color                 : blue
; text-decoration       : underline
}

body
{ background            : White !Important
; color                 : Black !Important
; font-family           : Serif !Important
; font-Size             : 14px  !Important
; text-align            : Left
; vertical-align        : Top
}

code
{ color                 : #333377
}

table
{ border-bottom         : 1px solid #cccccc
; border-right          : 1px solid #cccccc
}

td
{ border-left           : 1px solid #cccccc
; border-top            : 1px solid #cccccc
}

.TocTableHeading
{ font-size		: 20px
}

/* the following allow exceedingly varied display, if required */

.ComponentDetailHeading
,.ComponentSummaryHeading
,.EnumsHeading
,.EventDetailHeading
,.EventsInheritedHeading
,.EventSummaryHeading
,.FieldDetailHeading
,.FieldsInheritedHeading
,.FieldSummaryHeading
,.MethodDetailHeading
,.MethodsInheritedHeading
,.MethodSummaryHeading
,.PortsHeading
,.TypedefsHeading
{ background-color      : #cccccc
; font-size             : 20px
; font-weight           : bold
}

.ComponentDetail
,.ComponentSummary
,.Enums
,.EventDetail
,.EventsInherited
,.EventSummary
,.FieldDetail
,.FieldsInherited
,.FieldSummary
,.MethodDetail
,.MethodsInherited
,.MethodSummary
,.Ports
,.Typedefs
{ font-size             : 14px
}

/* used with --auto-pre-doc-comments: */

.PreText
{ background            : White !Important
; color                 : Black !Important
; font-family           : Serif !Important
; font-Size             : 14px  !Important
; text-align            : Left
; vertical-align        : Top
}
""")
        css.close()

    # ........................................................
    def create_all_defs_frame(self,defined_things_to_display):
        fn   = self._pathman.get_all_defs_frame_html()
        #if debug_level > 0 :
        #   print "Writing all structs frame as : " + all_structs_frame_filename
        html = open(fn, 'w')
        lang = self._lang

        if lang == 'specman':
            what_theyre_called      = 'structs'
            what_theyre_called_CAPS = 'Structs'
        elif lang == 'vera':
            what_theyre_called      = 'classes'
            what_theyre_called_CAPS = 'Classes'
        elif lang == 'vhdl':
            what_theyre_called      = 'design-units'
            what_theyre_called_CAPS = 'Design-Units'

	doctype = vzDoc_util.htmlDoctype()
	metas   = vzDoc_util.metaTags()
        html.write("""\
%(doctype)s
<!--NewPage-->
<HTML>
<HEAD>
%(metas)s
<TITLE>
All %(what_theyre_called)s
</TITLE>
</HEAD>
<BODY>
<H1 CLASS="TocTableHeading">All %(what_theyre_called_CAPS)s</H1>
<BR>
<TABLE WIDTH="100%%" SUMMARY="All %(what_theyre_called_CAPS)s" CLASS=\"TocTable\">
""" % vars())

        for dt in defined_things_to_display:
           html.write("<TR CLASS=\"TocTableRow\">\n")
           if len(string.split(dt, " ")) == 1 :
              html.write("<TD NOWRAP>\n")
           else :
              html.write("<TD ALIGN=\"right\" NOWRAP>\n")
           html.write(self.get_defd_hyperlink(dt) + "\n")
           html.write("</TD></TR>\n")

        html.write("</TABLE>\n</BODY>\n</HTML>\n")
        html.close()

    # ........................................................
    def create_use_html(self, usename, use_nodes):
        """
        Create HTML page for uses of a particular thing.
        """
        #print 'nodes',`use_nodes`
        #if debug_level > 0 :
        #   print "create_struct_html(struct_name = '" + struct_name + "' struct_node_list =", struct_node_list, \
        #         "struct_name_list = ", struct_name_list, ")"

        fn = self._pathman.get_use_html(usename)
        #print "Writing out HTML for '" + usename + "' to " + fn
        #print 'nodes',`use_nodes`
        html = open(fn, 'w')

        try :
           login_name = os.environ["USER"]
        except KeyError:
           try :
              login_name = os.environ["LOGNAME"]
           except KeyError:
              login_name = "user UID=" + str(os.getuid())

        when    = time.asctime()
        version = self._ctrl.vzDocVersion()
        doctype = vzDoc_util.htmlDoctype()
	metas   = vzDoc_util.metaTags()

        html.write("""\
%(doctype)s
<!--NewPage-->
<HTML>
<HEAD>
%(metas)s
<TITLE>
%(usename)s</TITLE>
</HEAD>
<BODY>
<P ALIGN="right"><A HREF="http://www.verilab.com/">www.verilab.com</A></P>
""" % vars()) # "

        lang = self._lang
        if lang == 'specman':
            what_its_called         = 'struct'
            what_theyre_called      = 'structs'
            what_theyre_called_CAPS = 'Structs'
            INTERESTING_STMTS = ["UNIT_STATEMENT", "STRUCT_STATEMENT"]
        elif lang == 'vera':
            what_its_called         = 'class'
            what_theyre_called      = 'classes'
            what_theyre_called_CAPS = 'Classes'
            INTERESTING_STMTS = ["STRUCT_STATEMENT"]
        elif lang == 'vhdl':
            what_its_called         = 'design-unit'
            what_theyre_called      = 'design-units'
            what_theyre_called_CAPS = 'Design-units'
            INTERESTING_STMTS = ["PACKAGE_DECLARATION","ENTITY_DECLARATION"] # ToDo: really should be: package<something> etc
        else:
             raise 'undue panic'

        use_words = string.split(usename, " ")

        # Get the initial node that defined the (e:struct or unit, vera: class, vhdl: package or entity)
        use_node = None
        for use_node in use_nodes:
           if use_node.nodeName in INTERESTING_STMTS:
              break

        if (use_node == None) \
	or use_node.nodeName not in INTERESTING_STMTS \
           and len(string.split(usename, " ")) == 1 \
           and usename not in ["sys", "global"] :
           html.write("""\
<H3>No fields, methods or events specific to this %(what_its_called)s</H3>
</BODY>
</HTML>
""" % vars())
	   html.close()
           return

        initial_node = use_node # Assign this before we mess it up next

        field_nodes     = []
        method_nodes    = []
        event_nodes     = []
        typedef_nodes   = [] # NB: specman only
        port_nodes      = [] # NB: vera only
        enum_nodes      = [] # NB: vera only
        component_nodes = [] # NB: vhdl only

        for use_node in use_nodes:
            field_nodes  = field_nodes  + vzDoc_dom.getChildNodes(use_node, "FIELD_DECLARATION")
            method_nodes = method_nodes + vzDoc_dom.getChildNodes(use_node, "METHOD_DECLARATION")
            event_nodes  = event_nodes  + vzDoc_dom.getChildNodes(use_node, "EVENT_DECLARATION")
            if lang == 'specman':
               typedef_nodes = typedef_nodes + vzDoc_dom.getChildNodes(use_node, "TYPE_STATEMENT")
            if lang == 'vera':
               port_nodes = port_nodes + vzDoc_dom.getChildNodes(use_node, "PORT_DECLARATION")
               enum_nodes = enum_nodes + vzDoc_dom.getChildNodes(use_node, "ENUM_DECLARATION")
            if lang == 'vhdl':
               component_nodes = component_nodes + vzDoc_dom.getChildNodes(use_node, "COMPONENT_DECLARATION")

        # all gets a bit hairy here...
        if lang == 'specman':
            if usename == "_Global" :
                html.write("<H1>" + self.get_defd_hyperlink(usename) + "\n")
            else :
                if initial_node.nodeName == "UNIT_STATEMENT":
                   html.write("<H1>Unit ")
                else :
                   html.write("<H1>Struct ")

                for word in use_words :
                   if word == use_words[-1] :
                      html.write(self.get_defd_hyperlink(word) + "\n")
                   else :
                      html.write(word + " ")
                      
            html.write("</H1>\n" + "&nbsp;"*8)

            self.show_class_hierarchy(html, usename)

            # Get doc comment for this struct/unit

            if initial_node.nodeName in INTERESTING_STMTS:
                if usename != "_Global" :
                    filename    = vzDoc_dom.getEnclosingFilename(initial_node)
                    line_number = vzDoc_dom.getLineNumber(initial_node, "STRUCT_ID")
                    html.write(self._doc_comment_manager.fullDocComment(filename, line_number, usename))
                html.write("<P>")

        elif lang == 'vera':
            if usename == "_Global" :
                html.write("<H1>" + self.get_defd_hyperlink(usename) + "\n</H1>" + "&nbsp;"*8)
            else :
                html.write("<H1>Class " + self.get_defd_hyperlink(usename) + "\n</H1>\n" + "&nbsp;"*8)

            self.show_class_hierarchy(html, usename)

            # Get doc comment for this class

            if initial_node.nodeName == "STRUCT_STATEMENT":
		# ToDo: should this get getEnclosingFilename? (no, it's vera-ish)
                if usename != "_Global" :
                    filename    = os.path.basename(vzDoc_dom.getFilename(initial_node, "STRUCT_ID"))
                    line_number = vzDoc_dom.getLineNumber(initial_node, "STRUCT_ID")
                    html.write(self._doc_comment_manager.fullDocComment(filename, line_number, usename))
                html.write("<P>")

        elif lang == 'vhdl':
            if initial_node.nodeName == "PACKAGE_DECLARATION" :
               html.write("<H2>Package ")
            elif initial_node.nodeName == "ENTITY_DECLARATION" :
               html.write("<H2>Entity ")
            else :
               raise 'panic panic panic, not package or entity'

            html.write(self.get_defd_hyperlink(usename) + "\n</H2>\n")
            # Get doc comment for this class

            if initial_node.nodeName == "ENTITY_DECLARATION" :
                self.do_vhdl_interfaces(html, initial_node)

            if initial_node.nodeName in INTERESTING_STMTS:
                filename    = vzDoc_dom.getEnclosingFilename(initial_node)
                line_number = vzDoc_dom.getLineNumber(initial_node, "STRUCT_ID")
                html.write(self._doc_comment_manager.fullDocComment(filename, line_number, usename))
                html.write("<P>")

        else:
            raise 'panic panic panic'


        # . . . . . . . . . . . . . .  . . . . .  ..

        if field_nodes == [] and method_nodes == [] and event_nodes == [] \
	 and (lang != 'vera' or usename != "_Global") \
         and (lang != 'specman' or usename != "_Global") \
         and (lang != 'vhdl') :
           html.write("<H3>No fields, methods or events specific to this struct</H3>")

        self.do_field_summary(html, field_nodes)
        self.do_fields_inherited(html, usename)
        self.do_method_summary(html, method_nodes)
        self.do_methods_inherited(html, usename)
        self.do_component_summary(html, component_nodes)
        self.do_event_summary(html, event_nodes)
        self.do_events_inherited(html, usename)
        self.do_ports(html, port_nodes)
        self.do_enums(html, enum_nodes)
        self.do_typedefs(html, typedef_nodes)
        self.do_field_detail(html, field_nodes)
        self.do_method_detail(html, method_nodes)
        self.do_component_detail(html, component_nodes)
        self.do_event_detail(html, event_nodes)

        html.write("""\
<P>Generated by vzDoc version %(version)s on %(when)s by %(login_name)s</P>
</BODY>
</HTML>
""" % vars())
        html.close()


    # ............................................................
    def show_class_hierarchy(self, html, struct_id) :
         hierarchy = self._inheritance_tree.getSuperClassHierarchy(struct_id)
         if len(hierarchy) > 1 :
            html.write("<PRE>\n")
            html.write(self.get_defd_hyperlink(hierarchy[0][0]) + "\n")
            indent = 0
            for level in hierarchy[1:] :
                html.write(" " + "     " * indent + "|\n")
                html.write(" " + "     " * indent + "+--")
                for clazz in level :
                   if level == hierarchy[-1] :
                       html.write(clazz)
                   else :
                       html.write(self.get_defd_hyperlink(clazz))
                       if clazz != level[-1] :
                           html.write(", ")
                html.write("\n")
                indent += 1
            html.write("</PRE>\n")
            

    # ............................................................
    def dontDisplay(self, doc_comment):
        """Use the keywords on the front of a doc comment, plus
        the setting of the --dont-display command-line flag,
	to decide if we display this thing or not.

        We are liberal about this : if in the slightest doubt,
        we *do* display (return 0).
        """
        excl_tags = self._ctrl.excludeTags()
        if excl_tags == None: return 0

        #print 'tags=',`excl_tags`,'comment=',doc_comment

        doc_comment_tags = self._doc_comment_manager.docCommentTags(doc_comment)
        if doc_comment_tags == None: return 0

        for dct in doc_comment_tags:
            if dct in excl_tags: return 1

        return 0

    # ............................................................
    def get_fileline_hyperlink(self,src_filename, dst_filename, line_num):
        #print "get_fileline_hyperlink(src_filename = '" + src_filename + "', dst_filename = '" + dst_filename + "', line_num = " + `line_num` + ")"
        line_just_before1 = string.atoi(line_num) - 1
        if line_just_before1 < 0 :
           line_just_before1 = 0
	line_just_before = str(line_just_before1)

        pathman = self._pathman
        code_html_full_path     = pathman.get_code_html_full_path(dst_filename)
        code_html_relative_path = pathman.get_relative_path(src_filename, code_html_full_path)
        file_link = code_html_relative_path + "#" + line_just_before
        file_text = dst_filename + " @ line " + line_num

        return '<A HREF="%s" TARGET="%sFrame">%s</A>\n' % (file_link,self.get_frame_name(),file_text)

    # ............................................................
    def get_type_text(self, node):
        """
        Get type text for the node, which may be scalar, sub type or
        list or combination of them, and if the type is known, then
        hyperlink it

        Can also be *absolutely nothing*; that's OK, too.

        NB: pretty language specific! ToDo?
        """
        # ToDo: is the 'absolutely nothing' bit right???

        if self._lang == 'vera':
            #print("get_type_text(node=", node, "hyperlinks_list=", hyperlinks_list)

            type_name = vzDoc_dom.getFirstChildText(node, "SCALAR_TYPE_ID")
            assert(type_name != None)

            if type_name in self._defined_things:
                type_name = self.get_defd_hyperlink(type_name)

            if "_Global." + type_name in self._defined_things:
#                id_file = os.path.basename(vzDoc_dom.getFilename(node, "SCALAR_TYPE_ID"))
#                id_line = vzDoc_dom.getLineNumber(node, "SCALAR_TYPE_ID")
                type_name = self.get_global_hyperlink(type_name) #,id_file,id_line)

            return "<EM>" + type_name + "</EM>"

        elif self._lang == 'specman':

            #print("get_type_text(node=", node, "struct_name_list=", struct_name_list)

            list_text = ""
            list_node = vzDoc_dom.getFirstChildNode(node, "LIST_TYPE")
            if list_node != None:
               list_text = "list of "

            scalar_text = vzDoc_dom.getFirstChildText(node, "SCALAR_TYPE_ID")
            sub_text    = vzDoc_dom.getFirstChildText(node, "STRUCT_SUBTYPE_ID")

            #print "scalar_text :", scalar_text, "sub_text :", sub_text

            if scalar_text != None and sub_text != None :
                raise "Found both SCALAR_TYPE_ID and STRUCT_SUBTYPE_ID"
            elif scalar_text == None and sub_text == None :
                assert(list_node == None) # don't want 'list of <nothing>'
                return ''
	    elif scalar_text == None:
		text = sub_text
	    elif sub_text == None:
		text = scalar_text

            #print text, struct_name_list

            if text in self._defined_things:
               text = self.get_defd_hyperlink(text) + "\n"

            if "_Global." + text in self._defined_things:
               text = self.get_global_hyperlink(text) #,id_file,id_line)

	    #print >> sys.stderr, 'list_text=<',list_text,'> text=<',text,'>'

            return list_text + text

        elif self._lang == 'vhdl':
            # ToDo: just a copy of the Specman one for now
            # print("get_type_text(node=", node)

            text = vzDoc_dom.getFirstChildText(node, "SCALAR_TYPE_ID")
            #print "text :", text

            if text in self._defined_things:
               text = self.get_defd_hyperlink(text) + "\n"

            return "<EM>" + text + "</EM>"

        else:
            raise 'panic panic panic'

    # ............................................................
    # ToDo: these *_summary things and *_detail things *really*
    # need commoning up!
    # ............................................................

    def do_field_summary(self, fd, field_nodes):

	#for i in field_nodes:
        #    vzDoc_dom.prtNode(sys.stderr,i)

        if field_nodes == [] :
            return

#       if debug_level > 0 :
#          print "do_field_summary(fd=",fd,"field_nodes=",field_nodes,\
#                ") call"
	htmlclass = 'FieldSummary'
	start_table(fd, "Field summary", htmlclass)

        #print >> sys.stderr, 'field_nodes:',`field_nodes`

	(id_name_list, node_dir) = vzDoc_dom.get_sorted_node_list(field_nodes, "FIELD_DECLARATION_ID")
	for id_name in id_name_list :
            for node in node_dir[id_name]:
                #vzDoc_dom.prtNode(sys.stderr,node)

                if self._lang == 'vera':
                   id_file = os.path.basename(vzDoc_dom.getFilename(node, "FIELD_DECLARATION_ID"))
                else:
                   id_file = vzDoc_dom.getEnclosingFilename(node)
                id_line = vzDoc_dom.getLineNumber(node, "FIELD_DECLARATION_ID")
                doc_comment = self._doc_comment_manager.shortDocComment(id_file, id_line, id_name)

                # Don't display if the doc comment has a tag we're avoiding:
                if self.dontDisplay(doc_comment): continue

#                if debug_level > 1 :
#                print >> sys.stderr, "do_field_summary() : id_name =",id_name, "id_file =", id_file, "id_line =",id_line

                start_table_row_and_2cell(fd)
                fd.write(target(id_name))
                fd.write(self.get_type_text(node))
                next_table_cell(fd)
                fd.write(localHyperlink(id_name,id_file,id_line))
                if doc_comment != "" :
                    fd.write("<BR>" + "&nbsp;"*8 + doc_comment)
                end_table_cell_and_row(fd)

	end_table(fd)


    # ............................................................
    def do_fields_inherited(self, fd, struct_id) :
        (superclasses, inherited_fields_dir) = self._inheritance_tree.getAllInheritedFields(struct_id)
        #print  "Inherited fields ", struct_id, superclasses, inherited_fields_dir
        for superclass in superclasses :
            no_of_fields = len(inherited_fields_dir[superclass])
            if no_of_fields != 0 :
              htmlclass='FieldsInherited'
              start_itable(fd, "Fields inherited from " + self.get_defd_hyperlink(superclass) + "\n",htmlclass)
              start_table_row_and_1cell(fd)
              for field in inherited_fields_dir[superclass] :
                  fd.write("<A HREF=\"" + string.replace(superclass, " ", "__") + ".html#" + field + "\">" + field + "</A>")
                  if field != inherited_fields_dir[superclass][-1] :
                      fd.write(", ")                
              end_table_cell_and_row(fd)
              end_table(fd)
        return

    
    # ............................................................
    def do_field_detail(self, fd, field_nodes):

        if field_nodes == [] :
            return
        
        htmlclass = 'FieldDetail'
        start_table(fd, "Field detail",htmlclass)
        end_table(fd)
        fd.write("<BR>")

        # Possible ToDo: instead of redoing all this node sorting,
        # collecting, finding line numbers, etc., -- reuse what
        # what done in do_field_summary.

	(id_name_list, node_dir) = vzDoc_dom.get_sorted_node_list(field_nodes, "FIELD_DECLARATION_ID")
	for id_name in id_name_list :
            for node in node_dir[id_name]:

                if self._lang == 'vera':
                   id_file = os.path.basename(vzDoc_dom.getFilename(node, "FIELD_DECLARATION_ID"))
                else:
                   id_file = vzDoc_dom.getEnclosingFilename(node)
                id_line = vzDoc_dom.getLineNumber(node, "FIELD_DECLARATION_ID")
                doc_comment = self._doc_comment_manager.fullDocComment(id_file, id_line, id_name)

                # Don't display if the doc comment has a tag we're avoiding:
                if self.dontDisplay(doc_comment): continue

                if self._lang == 'vera':
                    fd.write("<H3>")
                    fd.write(self.get_type_text(node))
                    fd.write("&nbsp;")
                    fd.write(localTarget(id_name,id_file,id_line))
                    fd.write("</H3>")
                    if doc_comment != "" :
                       fd.write("&nbsp;"*8 + doc_comment)
                    fd.write("<BR>"*2 + "&nbsp;"*12 + "defined in : ")
                else:
                    fd.write("<H4>")
                    fd.write(localTarget(id_name,id_file,id_line))
                    fd.write(" : <EM>")
                    fd.write(self.get_type_text(node))
                    fd.write("</EM></H4>")
                    if doc_comment != "" :
                       fd.write("&nbsp;"*8 + doc_comment + "<BR><BR>")
                    fd.write("&nbsp;"*12 + "defined in : ")

                fd.write(self.get_fileline_hyperlink(fd.name, id_file, id_line))
                fd.write("<HR>\n")

        try :
          force_exception = os.environ["VZDOC_FORCE_EXCEPTION"]
          print "TEST_MODE : Forcing exception"
        except :
          force_exception = 0

        if force_exception :
           print this_variable_doesnt_exist


    # ............................................................
    def do_method_summary(self, fd, method_nodes):

        if method_nodes == [] :
            return

        #if debug_level > 0 :
        #   print "do_method_summary(fd = ", fd, ", method_nodes = ", \
        # method_nodes, ", struct_name_list = ", struct_name_list, ") call"

	htmlclass='MethodSummary'
        start_table(fd, "Method summary",htmlclass)
        done_methods = []

	(id_name_list, node_dir) = vzDoc_dom.get_sorted_node_list(method_nodes, "METHOD_NAME_ID")
	for id_name in id_name_list :
            for node in node_dir[id_name]:

                (id_name, id_line, return_type_text, tcm_clk) = self.get_method_info(node)
	        if self._lang == 'specman':
	             id_file = vzDoc_dom.getEnclosingFilename(node)
                elif self._lang == 'vera':
	             id_file = os.path.basename(vzDoc_dom.getFilename(node, "METHOD_NAME_ID"))
                elif self._lang == 'vhdl':
                     # ToDo: just copied Specman one for now
	             id_file = vzDoc_dom.getEnclosingFilename(node)
                else:
                    raise 'panic panic panic in do_method_summary'

                #if debug_level > 1 :
                #   print "do_method_summary() : id_name =",id_name, "id_file =", id_file, "id_line =", id_line

                if id_name in done_methods:
                   continue
                else :
                   done_methods.append(id_name)

                doc_comment = self._doc_comment_manager.shortDocComment(id_file, id_line, id_name)

                # Don't display if the doc comment has a tag we're avoiding:
                if self.dontDisplay(doc_comment): continue

                start_table_row_and_2cell(fd)
                fd.write(return_type_text)

                next_table_cell(fd)
                fd.write(target(id_name))
                fd.write(localHyperlink(id_name,id_file,id_line))
                fd.write(" (")
                param_list_node = vzDoc_dom.getFirstChildNode(node, "PARAMETER_LIST")
                self.do_parameter_summary(fd, param_list_node,'summary',0)
                # NB: do_parameter_summary handles None node
                fd.write(") ")
                fd.write(tcm_clk)

                if doc_comment != "" :
                   fd.write("<BR>" + "&nbsp;"*8 + doc_comment)

                end_table_cell_and_row(fd)

        end_table(fd)


    # ............................................................
    def do_methods_inherited(self, fd, struct_id) :
        (superclasses, inherited_methods_dir) = self._inheritance_tree.getAllInheritedMethods(struct_id)
        #print "Inherited methods ", struct_id, superclasses, inherited_methods_dir
        for superclass in superclasses :
            no_of_methods = len(inherited_methods_dir[superclass])
            if no_of_methods != 0 :
              htmlclass='MethodsInherited'
              start_itable(fd, "Methods inherited from " + self.get_defd_hyperlink(superclass) + "\n",htmlclass)
              start_table_row_and_1cell(fd)
              for method in inherited_methods_dir[superclass] :
                  fd.write("<A HREF=\""  + string.replace(superclass, " ", "__") + ".html#" + method + "\">" + method + "</A>")
                  if method != inherited_methods_dir[superclass][-1] :
                      fd.write(", ")                
              end_table_cell_and_row(fd)
              end_table(fd)
        return

    
    # ............................................................
    def do_method_detail(self, fd, method_nodes) :

        if method_nodes == [] :
            return
        
        start_table(fd, "Method detail",'MethodDetail')
        end_table(fd)
        fd.write("<BR>")

	(id_name_list, node_dir) = vzDoc_dom.get_sorted_node_list(method_nodes, "METHOD_NAME_ID")
	for id_name in id_name_list :
            for node in node_dir[id_name]:

                (id_name, id_line, return_type_text, tcm_clk) = self.get_method_info(node)

	        if self._lang == 'specman':
                    id_file = vzDoc_dom.getEnclosingFilename(node)
                elif self._lang == 'vera':
                    id_file = os.path.basename(vzDoc_dom.getFilename(node, "METHOD_NAME_ID"))
                elif self._lang == 'vhdl':
                    id_file = vzDoc_dom.getEnclosingFilename(node)
                else:
                    raise 'panic panic panic'

                doc_comment = self._doc_comment_manager.fullDocComment(id_file, id_line, id_name)

                # Don't display if the doc comment has a tag we're avoiding:
                if self.dontDisplay(doc_comment): continue

                if self._lang == 'specman':

                    fd.write("<H4>")
                    fd.write(localTarget(id_name,id_file,id_line))
                    fd.write(" (")
                    param_list_node = vzDoc_dom.getFirstChildNode(node, "PARAMETER_LIST")
                    self.do_parameter_summary(fd, param_list_node)
                    # NB: do_parameter_summary handles None node
                    fd.write(") : ")
                    fd.write(return_type_text)
                    fd.write(" ")
                    fd.write(tcm_clk)
                    fd.write("</H4>")
                    if doc_comment != "" :
                        fd.write("&nbsp;"*8 + doc_comment + "<BR><BR>")
                    fd.write("&nbsp;"*12 + "defined in : ")

                elif self._lang == 'vera':
                    fd.write("<H3>" + localTarget(id_name,id_file,id_line) + "</H3>")
                    fd.write("<PRE>" + return_type_text)
                    fd.write(" <B>")
                    fd.write(id_name)
                    fd.write("</B>(")
                    tabs = len(getTextOnly(return_type_text)) + len(id_name) + 2
                    param_list_node = vzDoc_dom.getFirstChildNode(node, "PARAMETER_LIST")
                    self.do_parameter_summary(fd, param_list_node, "detail", tabs)
                    # NB: do_parameter_summary handles None node
                    fd.write(")</PRE>")
                    fd.write("&nbsp;"*8 + doc_comment )
                    fd.write("<BR>"*2 + "&nbsp;"*12 + "defined in : ")

                elif self._lang == 'vhdl':
                    fd.write("<H3>" + localTarget(id_name,id_file,id_line) + "</H3>")
                    fd.write("<PRE>" + return_type_text)
                    fd.write(" <B>")
                    fd.write(id_name)
                    fd.write("</B>(")
                    tabs = len(getTextOnly(return_type_text)) + len(id_name) + 2
                    param_list_node = vzDoc_dom.getFirstChildNode(node, "PARAMETER_LIST")
                    self.do_parameter_summary(fd, param_list_node, "detail", tabs)
                    # NB: do_parameter_summary handles None node
                    fd.write(")</PRE>")
                    fd.write("&nbsp;"*8 + doc_comment )
                    fd.write("<BR>"*2 + "&nbsp;"*12 + "defined in : ")

                else:
                    raise 'panic panic panic'

                fd.write(self.get_fileline_hyperlink(fd.name, id_file, id_line))
                fd.write("<BR>")
                fd.write("<HR>\n")

    # ............................................................
    def do_component_summary(self, fd, component_nodes):

        if component_nodes == [] :
            return
        
        #print "do_component_summary(fd = ", fd, ", component_nodes = ", component_nodes, ") Call"

	htmlclass='ComponentSummary'
        start_table(fd, "Component summary",htmlclass)

	(id_name_list, node_dir) = vzDoc_dom.get_sorted_node_list(component_nodes, "COMPONENT_ID")
	for id_name in id_name_list :
            for node in node_dir[id_name]:

                (id_name, id_line) = self.get_component_info(node)
                id_file = vzDoc_dom.getEnclosingFilename(node)

                #if debug_level > 1 :
                #   print "do_component_summary() : id_name =",id_name, "id_file =", id_file, "id_line =", id_line

                doc_comment = self._doc_comment_manager.shortDocComment(id_file, id_line, id_name)

                # Don't display if the doc comment has a tag we're avoiding:
                if self.dontDisplay(doc_comment): continue

                start_table_row_and_1cell(fd)
                fd.write(localHyperlink(id_name,id_file,id_line))

                #fd.write(" (")
                #self.do_parameter_summary(fd, vzDoc_dom.getFirstChildNode(node, "PARAMETER_LIST"),'summary',0)
                #fd.write(") ")
                #fd.write(tcm_clk)

                if doc_comment != "" :
                   fd.write("<BR>" + "&nbsp;"*8 + doc_comment)

                end_table_cell_and_row(fd)

        end_table(fd)

    # ............................................................
    def do_component_detail(self, fd, component_nodes) :

        if component_nodes == [] :
            return

        start_table(fd, "Component detail",'ComponentDetail')
        end_table(fd)
        fd.write("<BR>")

	(id_name_list, node_dir) = vzDoc_dom.get_sorted_node_list(component_nodes, "COMPONENT_ID")
	for id_name in id_name_list :
            for node in node_dir[id_name]:

                (id_name, id_line) = self.get_component_info(node)

                if self._lang == 'vhdl':
                    id_file = vzDoc_dom.getEnclosingFilename(node)
                else:
                    raise 'panic panic panic'

                doc_comment = self._doc_comment_manager.fullDocComment(id_file, id_line, id_name)

                # Don't display if the doc comment has a tag we're avoiding:
                if self.dontDisplay(doc_comment): continue

                if self._lang == 'vhdl':
                    fd.write("<H3>" + localTarget(id_name,id_file,id_line) + "</H3>")
                    self.do_vhdl_interfaces(fd, node)
                    fd.write("&nbsp;"*8 + doc_comment )
                    fd.write("<BR>" + "&nbsp;"*12 + "defined in : ")

                else:
                    raise 'panic panic panic'

                fd.write(self.get_fileline_hyperlink(fd.name, id_file, id_line))
                fd.write("<BR>")
                fd.write("<HR>\n")

    # ............................................................
    def do_vhdl_interfaces(self, fd, node):
         fd.write("<PRE>")
         for interface in ["GENERIC_INTERFACE", "PORT_INTERFACE"] :
             interface_node = vzDoc_dom.getFirstChildNode(node, interface)
             if interface_node == None: continue

             interface_name = string.lower(string.split(interface, "_")[0])
             fd.write(" <B>" + interface_name + "</B>(")
             tabs = len(interface_name) + 2
             parameter_list_node = vzDoc_dom.getFirstChildNode(interface_node, "PARAMETER_LIST")
             self.do_parameter_summary(fd, parameter_list_node, "detail", tabs)
             # NB: do_parameter_summary handles None node
             fd.write(")")
             if interface == "GENERIC_INTERFACE" :
               fd.write("\n\n")
         fd.write("</PRE>")

    # ............................................................
    def do_parameter_summary(self, fd, parameter_list_node,section=None,tabs=0):
        """
        section and tabs used only by Vera
        """
        #if debug_level > 0 :
        #    print "do_parameter_summary(fd=", fd, "parameter_list_node=", parameter_list_node
        if parameter_list_node == None :
            return
        parameters = vzDoc_dom.getChildrenOfType(parameter_list_node, "PARAMETER")
        lang = self._lang

        for node in parameters :
            if lang == 'specman':
                node_text = vzDoc_dom.getFirstChildText(node, "PARAMETER_ID")
                assert(node_text != None)
                fd.write(node_text)
                fd.write(" : ");
                fd.write(self.get_type_text(node))
                if node != parameters[-1] :
                   fd.write(", ");
            elif lang == 'vera':
                node_text = vzDoc_dom.getFirstChildText(node, "PARAMETER_ID")
                assert(node_text != None)
                fd.write(self.get_type_text(node))
                if section == "detail" :
                   fd.write(" ");
                else :
                   fd.write("&nbsp;&nbsp;");
                fd.write(node_text)
                if node != parameters[-1] :
                   fd.write(", ");
                   if section == "detail" :
                      fd.write("\n" + " "*tabs);
            elif lang == 'vhdl':
                param_id_list = vzDoc_dom.getChildrenOfType(node, "PARAMETER_ID")
                for param_id_node in param_id_list :
                     param_id = vzDoc_dom.getText(param_id_node)
                     fd.write('%-15s' % param_id)
                     if section == "detail" :
                        fd.write(" : ");
                     else :
                        fd.write("&nbsp;:&nbsp;");

                     if section == "detail" :
                         mod_text = vzDoc_dom.getFirstChildText(node, "PARAM_MODIFIER")
                         if mod_text != None:
                             fd.write('%-6s' % mod_text)
                     else :
                         fd.write(" ");
                     fd.write(self.get_type_text(node))
                if node != parameters[-1] :
                   fd.write(", ");
                   if section == "detail" :
                      fd.write("\n" + " "*tabs);
            else:
                raise 'panic panic panic'

    # ............................................................
    def get_method_info(self, node):
	"""
        Get a basic tuple of info from a method node
        """
        id_name          = vzDoc_dom.getFirstChildText(node, "METHOD_NAME_ID")
        assert(id_name != None)
        id_line      = vzDoc_dom.getLineNumber(node, "METHOD_NAME_ID")
        return_type_node = vzDoc_dom.getFirstChildNode(node, "RETURN_TYPE")

        # print >> sys.stderr, "return_type_node",return_type_node
        if return_type_node != None :
            return_type_text = self.get_type_text(return_type_node)
            # print >> sys.stderr, "   return_type_text",return_type_text

        if return_type_node == None or return_type_text == "" :
	    return_type_text = 'void'

        tcm_clk = vzDoc_dom.getFirstChildText(node, "EVENT_ID")

        if self._lang == 'vera':
            assert(tcm_clk == None)

        if tcm_clk == None :
            tcm_clk = ''
        else:
            tcm_clk = "@" + tcm_clk

        return(id_name, id_line, return_type_text, tcm_clk)


    # ............................................................
    def get_component_info(self, node):
	"""
        Get a basic tuple of info from a component node
        """
        id_name          = vzDoc_dom.getFirstChildText(node, "COMPONENT_ID")
        assert(id_name != None)
        id_line      = vzDoc_dom.getLineNumber(node, "COMPONENT_ID")

        return(id_name, id_line)


    # ............................................................
    def do_event_summary(self, fd, nodes):

        if nodes == [] :
            return
        
	htmlclass='EventSummary'
	start_table(fd, "Event summary",htmlclass)

        (id_name_list, node_dir) = vzDoc_dom.get_sorted_node_list(nodes, "EVENT_ID")
        for id_name in id_name_list:
            for node in node_dir[id_name]:

                (id_name, id_line, id_file) = self.get_event_info(node)
                doc_comment = self._doc_comment_manager.shortDocComment(id_file, id_line, id_name)

                # Don't display if the doc comment has a tag we're avoiding:
                if self.dontDisplay(doc_comment): continue

                start_table_row_and_1cell(fd)
                fd.write(target(id_name))
                fd.write(localHyperlink(id_name,id_file,id_line))
                if doc_comment != "" :
                   fd.write("<BR>" + "&nbsp;"*8 + doc_comment)
                end_table_cell_and_row(fd)

        end_table(fd)


    # ............................................................
    def do_events_inherited(self, fd, struct_id) :
        (superclasses, inherited_events_dir) = self._inheritance_tree.getAllInheritedEvents(struct_id)
        #print  "Inherited events ", struct_id, superclasses, inherited_events_dir
        for superclass in superclasses :
            no_of_events = len(inherited_events_dir[superclass])
            if no_of_events != 0 :
	      htmlclass='EventsInherited'
              start_itable(fd, "Events inherited from " + self.get_defd_hyperlink(superclass) + "\n",htmlclass)
              start_table_row_and_1cell(fd)
              for event in inherited_events_dir[superclass] :
                  fd.write("<A HREF=\""  + string.replace(superclass, " ", "__") + ".html#" + event + "\">" + event + "</A>")
                  if event != inherited_events_dir[superclass][-1] :
                      fd.write(", ")                
              end_table_cell_and_row(fd)
              end_table(fd)
        return

    
    # ............................................................
    def do_event_detail(self, fd, nodes):

        if nodes == [] :
            return
        
        start_table(fd, "Event detail",'EventDetail')
        end_table(fd)
        fd.write("<BR>")

        (id_name_list, node_dir) = vzDoc_dom.get_sorted_node_list(nodes, "EVENT_ID")
        for id_name in id_name_list:
            for node in node_dir[id_name]:

                (id_name, id_line, id_file) = self.get_event_info(node)
                doc_comment = self._doc_comment_manager.fullDocComment(id_file, id_line, id_name)

                # Don't display if the doc comment has a tag we're avoiding:
                if self.dontDisplay(doc_comment): continue

                fd.write("<H4>")
                fd.write(localTarget(id_name,id_file,id_line))
                fd.write("</H4>")
                if self._lang == 'specman':
                    if doc_comment != "" :
                        fd.write("&nbsp;"*8 + doc_comment + "<BR><BR>")
                    fd.write("&nbsp;"*12 + "defined in : ")
                elif self._lang == 'vera':
                    fd.write("&nbsp;"*8 + doc_comment )
                    fd.write("<BR>"*2 + "&nbsp;"*12 + "defined in : ")

                fd.write(self.get_fileline_hyperlink(fd.name, id_file, id_line))
                fd.write("<HR>\n")

    # ............................................................
    def get_event_info(self, node) :
        "Get tuple of info for events"
        id_name     = vzDoc_dom.getFirstChildText(node, "EVENT_ID")
        assert(id_name != None)
        id_line = vzDoc_dom.getLineNumber(node, "EVENT_ID")
        id_file = vzDoc_dom.getEnclosingFilename(node)
        return (id_name, id_line, id_file)

    # ............................................................
    def do_ports(self, fd, nodes):
        """
        NB: vera only
        """
        
        if nodes == [] :
            return
        
        start_table(fd, "Ports",'Ports')
        end_table(fd)
        fd.write("<BR>")
        done = {} # key is id_name/id_file/id_line

        (id_name_list, node_dir) = vzDoc_dom.get_sorted_node_list(nodes, "PORT_NAME_ID")

        for id_name in id_name_list :
            for node in node_dir[id_name]:
                id_file = os.path.basename(vzDoc_dom.getFilename(node, "PORT_NAME_ID"))
                id_line = vzDoc_dom.getLineNumber(node, "PORT_NAME_ID")

                key = '%s/%s/%s' % (id_name,id_file,id_line)
                if done.has_key(key): continue
                done[key] = 1

                doc_comment = self._doc_comment_manager.fullDocComment(id_file, id_line, id_name)

                # Don't display if the doc comment has a tag we're avoiding:
                if self.dontDisplay(doc_comment): continue

                fd.write("<PRE><B>")
                fd.write(localTarget(id_name,id_file,id_line,simple_anchor=1))
                fd.write("</B>{")
                tabs = len(id_name) + 1
                signal_list_node = vzDoc_dom.getFirstChildNode(node, "SIGNAL_LIST")
                assert(signal_list_node != None)
                self.do_signals(fd, signal_list_node, tabs)
                fd.write("}\n</PRE>")
                if doc_comment != "" :
                    fd.write("&nbsp;"*8 + doc_comment)
                fd.write("<BR>"*2 + "&nbsp;"*12 + "defined in : ")
                fd.write(self.get_fileline_hyperlink(fd.name, id_file, id_line))
                fd.write("<HR>\n")

    # ............................................................
    def do_signals(self, fd, signal_list_node, tabs) :
	"""
        Write port signals to HTML
        """
        #print "do_signals(fd=", fd, "signal_list_node=", signal_list_node)
        if signal_list_node == None :
            return
        signals = vzDoc_dom.getChildrenOfType(signal_list_node, "SIGNAL_NAME_ID")
        for node in signals :
            node_text = vzDoc_dom.getFirstChildText(node, "SIGNAL_NAME_ID")
            assert(node_text != None)
            fd.write(node_text)
            if node != signals[-1] :
               fd.write(";");
               fd.write("\n" + " "*tabs);

    # ............................................................
    def do_enums(self, fd, nodes):
        """
        NB: vera only
        """
        if nodes == [] :
            return
                
        start_table(fd, "Enums",'Enums')
        end_table(fd)
        fd.write("<BR>")
        done = {} # key is id_name/id_file/id_line

        (id_name_list, node_dir) = vzDoc_dom.get_sorted_node_list(nodes, "ENUM_NAME_ID")
        for id_name in id_name_list :
            for node in node_dir[id_name]:
                id_file = os.path.basename(vzDoc_dom.getFilename(node, "ENUM_NAME_ID"))
                id_line = vzDoc_dom.getLineNumber(node, "ENUM_NAME_ID")

                key = '%s/%s/%s' % (id_name,id_file,id_line)
                if done.has_key(key): continue
                done[key] = 1

                doc_comment = self._doc_comment_manager.fullDocComment(id_file, id_line, id_name)

                # Don't display if the doc comment has a tag we're avoiding:
                if self.dontDisplay(doc_comment): continue

                fd.write("<PRE><B>")
                fd.write(localTarget(id_name,id_file,id_line,simple_anchor=1))
                fd.write("</B>{")
                tabs = len(id_name) + 1
                enum_list_node = vzDoc_dom.getFirstChildNode(node, "ENUM_LIST")
                assert(enum_list_node != None)
                self.do_enum_items(fd, enum_list_node, tabs)
                fd.write("}\n</PRE>")
                if doc_comment != "" :
                    fd.write("&nbsp;"*8 + doc_comment)
                fd.write("<BR>"*2 + "&nbsp;"*12 + "defined in : ")
                fd.write(self.get_fileline_hyperlink(fd.name, id_file, id_line))
                fd.write("<HR>\n")

    # ............................................................
    def do_typedefs(self, fd, nodes):
        """
        NB: specman only
        """
        if nodes == [] :
            return
        
        start_table(fd, "Typedefs",'Typedefs')
        end_table(fd)
        fd.write("<BR>")
        done = {} # key is id_name/id_file/id_line

        (id_name_list, node_dir) = vzDoc_dom.get_sorted_node_list(nodes, "TYPE_STATEMENT_ID")
        for id_name in id_name_list :
            for node in node_dir[id_name]:
                id_file = vzDoc_dom.getEnclosingFilename(node)
                id_line = vzDoc_dom.getLineNumber(node, "TYPE_STATEMENT_ID")

                key = '%s/%s/%s' % (id_name,id_file,id_line)
                if done.has_key(key): continue
                done[key] = 1

                doc_comment = self._doc_comment_manager.fullDocComment(id_file, id_line, id_name)

                # Don't display if the doc comment has a tag we're avoiding:
                if self.dontDisplay(doc_comment): continue

                fd.write("<PRE><B>")
                fd.write(localTarget(id_name,id_file,id_line,simple_anchor=1))
                fd.write("</B> ")
                tabs = len(id_name) + 2
                enum_list_node = vzDoc_dom.getFirstChildNode(node, "ENUM_LIST")
                scalar_text    = vzDoc_dom.getFirstChildText(node, "SCALAR_TYPE_ID")

                assert(enum_list_node != None or scalar_text != None)
                if (enum_list_node != None) :
                   fd.write("[")
                   self.do_enum_items(fd, enum_list_node, tabs)
                   fd.write("]")
                else :
                   fd.write(scalar_text)

                fd.write("\n</PRE>")
                if doc_comment != "" :
                    fd.write("&nbsp;"*8 + doc_comment)
                fd.write("<BR>"*2 + "&nbsp;"*12 + "defined in : ")
                fd.write(self.get_fileline_hyperlink(fd.name, id_file, id_line))
                fd.write("<HR>\n")

    # ............................................................
    def do_enum_items(self, fd, enum_list_node, tabs) :

       #print "write_out_signals(fd=", fd, "enum_list_node=", enum_list_node)

       if enum_list_node == None :
           return
       enum_items = vzDoc_dom.getChildrenOfType(enum_list_node, "ENUM_ITEM_ID")
       for node in enum_items :
           node_text = vzDoc_dom.getFirstChildText(node, "ENUM_ITEM_ID")
           assert(node_text != None)
           fd.write(node_text)
           if node != enum_items[-1] :
              fd.write(",");
              fd.write("\n" + " "*tabs);

    # ............................................................
    def get_defd_hyperlink(self, text):

	return '<A HREF="%s.html" TARGET="%sFrame">%s</A>' % (
	    string.replace(text, " ", "__"), self.get_frame_name(), text)

    # ............................................................
    def get_global_hyperlink(self, id_name): #, id_file, id_line):
        "NB: vera or specman"
        assert(self._lang == 'vera' or self._lang == 'specman')
#        anchor = local_anchor(id_name,id_file,id_line)
        anchor = id_name
        return '<A HREF="_Global.html#%s" TARGET="%sFrame">%s</A>' % (anchor,self.get_frame_name(),id_name)

    def get_frame_name(self) :
        if self._lang == 'vera':
            frame_name = 'class'
        else :
            frame_name = 'struct'
        return frame_name

    def get_frame_name_all(self) :
        if self._lang == 'vera':
            frame_name_all = 'allClassesFrame'
        else :
            frame_name_all = 'allStructsFrame'
        return frame_name_all

# ============================================================
# END OF CLASS _Presenter
# ============================================================

# ............................................................
def getTextOnly(s) :
   """
   Returns the viewable text part of an HTML string without any of the
   tag stuff.
   """
   return re.sub("<.*?>", "", s)

# ............................................................
def localHyperlink(id_name,id_file,id_line):
    anchor = local_anchor(id_name,id_file,id_line)
    return '<A HREF="#%(anchor)s">%(id_name)s</A>' % vars()

def localTarget(id_name,id_file,id_line,simple_anchor=0):
    if simple_anchor:
        anchor = id_name
    else:
        anchor = local_anchor(id_name,id_file,id_line)
    return '<A NAME="%(anchor)s">%(id_name)s</A>' % vars()

def local_anchor(id_name,id_file,id_line):
    # ToDo: escape any weird metachars in this
    return '%s@%s:%s' % (id_name,id_file,id_line)

def target(target):
    return '<A NAME="%(target)s"><!-- --></A>\n' % vars()

# ............................................................
# A bunch of simple table formatters...

def start_table(fd, title, htmlclass='Unspecified'):
    fd.write("""\
<BR><A NAME="%(title)s"><!-- --></A>
<TABLE CLASS="%(htmlclass)s" WIDTH="100%%" SUMMARY="%(title)s">
<TR CLASS="%(htmlclass)sHeading">
<TD COLSPAN=2><B>%(title)s</B></TD>
</TR>
""" % vars()) # "

def start_itable(fd, title,htmlclass='Unspecified'):
    fd.write("""\
<BR>\
<TABLE CLASS="%(htmlclass)s" WIDTH="100%%">
<TR CLASS="%(htmlclass)sHeading">
<TD COLSPAN=2><B>%(title)s</B></TD>
</TR>
""" % vars()) # "

def start_table_row_and_1cell(fd):
    fd.write('<TR>\n')
    fd.write('<TD>\n')

def start_table_row_and_2cell(fd):
    fd.write('<TR>\n')
    fd.write('<TD ALIGN="right" VALIGN="top" WIDTH="2%">\n')

def next_table_cell(fd) :
    fd.write('</TD><TD>\n')

def end_table_cell_and_row(fd):
    fd.write('</TD></TR>\n')

def end_table(fd) :
    fd.write("</TABLE>\n")

# ============================================================
